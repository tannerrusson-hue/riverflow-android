# RiverFlow Android v1.3.4

# RiverFlow v1.3.0 — Bug ID + FlyBox Match

New in v1.3:
- New top-level **Bug ID + FlyBox** tab.
- Rear-camera bug photo capture inside RiverFlow.
- Guided field identification for mayflies, caddis, stoneflies, midges, and terrestrials.
- Life-stage, size, and color-aware fly-pattern recommendations.
- River-context rig/presentation advice using the last selected RiverFlow gauge.
- Bug Library with fast visual field cues.
- **My Fly Box**: photograph an open fly box once, tag the exact locations of flies, and save the map locally.
- **FlyBox Match**: RiverFlow ranks the flies you actually carry and highlights their exact positions in the saved box photo.
- **Live Fly Finder (beta)**: point the camera at the box and align it to the saved box image to see highlighted mapped fly positions.
- Android camera runtime permission + WebView camera permission handling.
- Android file/photo chooser fallback.

Important: automatic computer-vision insect recognition is not falsely simulated in this build. The camera, guided ID, recommendation engine, fly-box mapping, and live overlay are functional; the server-side vision model is the remaining connection required for fully automatic photo identification.

# RiverFlow Android v1.2

Mobile fly-fishing river intelligence for Utah, Wyoming and Idaho.

v1.2 tightens the decision layer: live gauge freshness, water temperature, weather/wind, dated local reports, verified agency Blue Ribbon evidence, conservative trophy evidence, current-location distance, fishing-only nearby results, and a decluttered fishing map. Blue Ribbon quality, big-fish potential, and verified big-fish evidence are intentionally separate signals.

The Android app contains the RiverFlow UI inside the APK and reads RiverFlow backend services for gauges, history and NWS weather. Nearby location is requested only when the angler taps Nearby; exact coordinates are kept in app memory for that session and are not saved by RiverFlow.

Build with `gradle :app:assembleDebug` using Android SDK 35 / Java 17+ / Gradle 8.9.


## v1.3.2 Fly Advisor
- Adds no-photo seasonal Fly Advisor.
- Uses selected river, current month/season, time of day, water temperature, report freshness, and river-specific hatch profiles.
- Matches seasonal recommendations against the user's saved My Fly Box inventory and can highlight exact mapped fly locations.
- Bug photo identification remains the higher-confidence on-water observation path when the vision backend is available.

## v1.3.4 multi-box Fly Advisor
RiverFlow can now keep multiple named fly boxes on-device. Box photos use IndexedDB, while lightweight box metadata/inventory stays local. Fly Advisor and Bug ID rank all mapped flies across all boxes and automatically select the #1 fly, with the source box and saved position shown.


## v1.3.7 guide flow
- Bug Reference cards now drill into one self-contained detail screen.
- Each detail screen includes reference photo, identification cues, life stage, integrated size guidance, recommended flies, rig advice, and saved fly-box matching.
- Added real-photo references for Stonefly, Scud, and Sowbug.
- Removed the separate Size Guide tab and Android camera permission.
