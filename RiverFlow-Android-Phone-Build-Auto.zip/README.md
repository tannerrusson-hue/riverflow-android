# RiverFlow Android v1.2

Mobile fly-fishing river intelligence for Utah, Wyoming and Idaho.

v1.2 tightens the decision layer: live gauge freshness, water temperature, weather/wind, dated local reports, verified agency Blue Ribbon evidence, conservative trophy evidence, current-location distance, fishing-only nearby results, and a decluttered fishing map. Blue Ribbon quality, big-fish potential, and verified big-fish evidence are intentionally separate signals.

The Android app contains the RiverFlow UI inside the APK and reads RiverFlow backend services for gauges, history and NWS weather. Nearby location is requested only when the angler taps Nearby; exact coordinates are kept in app memory for that session and are not saved by RiverFlow.

Build with `gradle :app:assembleDebug` using Android SDK 35 / Java 17+ / Gradle 8.9.
