# RiverFlow Android v1.1

Mobile fly-fishing river intelligence for Utah, Wyoming and Idaho.

This build contains the RiverFlow UI inside the APK and reads live RiverFlow backend services for gauges, water temperature, history and NWS weather. It adds RiverScore recommendations, Blue Ribbon prioritization, Trophy Potential and a Samsung-safe home-screen widget configuration flow.

Build with `gradle :app:assembleDebug` using Android SDK 35 / Java 17+ / Gradle 8.9.
