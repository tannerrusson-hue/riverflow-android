# RiverFlow Android + Home-Screen Widgets

This Android project adds a native widget layer to the existing RiverFlow web app.

## Included

- RiverFlow Android shell that loads the live web app.
- **RiverFlow Compact** widget (roughly 2×2): river, CFS, water temp, wind, update time.
- **RiverFlow Large** widget (roughly 4×2): river, CFS, water temp, today high/low, rain chance, wind, hatch summary, update time.
- Per-widget river picker with search across Utah, Wyoming and Idaho USGS gauges.
- Each widget can watch a different river.
- Automatic refresh target: every 30 minutes (Android may batch background work for battery life).
- Manual refresh button.
- Tapping a widget opens the exact selected gauge in RiverFlow.
- Uses the existing RiverFlow Vercel gauge and NWS weather services.

## Data endpoints

- Gauges: `https://riverflow-v2-gauges.vercel.app/api/gauges`
- Weather: `https://riverflow-v2-weather.vercel.app/api/weather`
- App: `https://riverflow-ut-wy.vercel.app`


## Build entirely from an Android phone

No computer is required. The project includes `.github/workflows/build-apk.yml`, which builds an installable `RiverFlow.apk` in GitHub Actions. See **PHONE_ONLY_BUILD.md** for the phone-only steps.

## Build in Android Studio

1. Open this folder in Android Studio.
2. Let Gradle sync. The project uses Android Gradle Plugin 8.7.3 and compile SDK 35.
3. If prompted, install Android SDK Platform 35.
4. Choose **Build > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Install and add the widget

1. Install the APK on the Android phone.
2. Long-press an empty area of the home screen.
3. Tap **Widgets**.
4. Find **RiverFlow**.
5. Choose **RiverFlow Compact** or **RiverFlow Large**.
6. Drag it to the home screen.
7. Search for a river and tap the gauge you want the widget to watch.

## Cloud build option

A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. If this project is pushed to a GitHub repository, running **Build RiverFlow APK** produces a downloadable debug APK artifact automatically.

## Notes

- USGS readings are provisional.
- Water temperature appears only where the selected gauge reports it.
- Weather is from the existing RiverFlow NWS forecast service at the gauge coordinates.
- Hatch text in the widget is seasonal planning guidance, not a live insect observation.
