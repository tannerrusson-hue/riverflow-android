# RiverFlow Android v1.9.0

Final Android source package using the approved RiverFlow v1.9.0 map-first web interface.

Included in this build:
- Utah, Wyoming, Idaho, and Montana river coverage
- River-first map home screen
- Stackable Big Fish / 20+ / Near Me / Blue Ribbon filters
- Named fishing reaches independent of gauge naming
- Topographic + satellite map modes
- Native Android GPS bridge
- Advisor, Bug Guide, and Fly Boxes
- Existing home-screen widgets

Build target: Android SDK 35 / Java 17.
