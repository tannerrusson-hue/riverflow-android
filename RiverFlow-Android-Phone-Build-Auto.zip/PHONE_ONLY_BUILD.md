# RiverFlow Android v1.3 — phone-only build

GitHub Actions builds the APK in the cloud; Android Studio is not required.

## Update an existing RiverFlow build

Replace the repository file named `RiverFlow-Android-Phone-Build-Auto.zip` with the new ZIP from ChatGPT, commit it, and the existing **Build RiverFlow APK** workflow will run automatically.

## v1.3 permissions

RiverFlow asks for **Camera** only when you open Bug ID / FlyBox camera features. Location is still requested only when you use Nearby.

## New v1.3 field workflow

1. Open **Bug ID + FlyBox**.
2. Take a bug photo or choose an existing image.
3. Use the guided insect group / life-stage picker while the automatic vision backend is being connected.
4. RiverFlow recommends pattern, size, color and presentation using the last river you viewed as context.
5. In **My Fly Box**, photograph your open fly box once and tag the locations of flies you carry.
6. After a hatch match, tap **Find these in my fly box** to highlight the exact mapped positions.
7. **Live Fly Finder (beta)** opens the camera with the saved box image and recommended markers overlaid so you can align the physical box.

The camera, recommendation engine, FlyBox inventory and overlays are local to the app. The automatic image-recognition service is intentionally not faked; it is the remaining server-side connection.
