# RiverFlow Android Phone Build v1.3.5

Free-mode release. AI photo recognition is disabled intentionally. Guided Bug ID uses the photo as a local reference and auto-generates the fly recommendation after the user selects insect group/life stage. Fly Advisor remains fully automatic and multi-box matching remains local on-device.
