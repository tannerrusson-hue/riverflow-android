# RiverFlow Android v1.3.4

Phone-first RiverFlow build.

## New in v1.3.4
- Multiple named fly boxes stored locally on the phone.
- Fly-box photos stored in IndexedDB instead of normal localStorage so several box photos can be retained.
- Existing v1.3.2 single fly box migrates to Fly Box 1 when possible.
- Fly Advisor searches every mapped box and automatically chooses one #1 fly.
- Recommendations show the box name and exact saved fly location; #2/#3 are backups.
- Bug ID can hand its recommendation directly to the same automatic multi-box matcher.

## Privacy/storage
Fly-box photos and mapped fly locations are local app data. Clearing RiverFlow app data or uninstalling the app removes them.
