# Build RiverFlow entirely from your Android phone

You do not need Android Studio or a computer. GitHub Actions builds the APK in the cloud.

## What you need

- Your Samsung/Android phone
- A free GitHub account
- Chrome
- Samsung My Files (already installed on most Galaxy phones)

## 1. Extract the RiverFlow ZIP

1. Download `RiverFlow-Android-Phone-Build.zip`.
2. Open **My Files** > **Downloads**.
3. Tap the ZIP and choose **Extract**.
4. You should get a folder named `RiverFlow-Android-Phone-Build`.

Important: keep all folders exactly as they are, including `.github/workflows/build-apk.yml`.

## 2. Put the project in GitHub

Create a new GitHub repository named `RiverFlow-Android` and add the extracted project files while preserving the folders.

The repository root must look like this:

```
.github/
  workflows/
    build-apk.yml
app/
  build.gradle
  src/
build.gradle
settings.gradle
gradle.properties
README.md
PHONE_ONLY_BUILD.md
```

## 3. Run the APK builder

1. Open the repository on GitHub.
2. Tap **Actions**.
3. Tap **Build RiverFlow APK**.
4. Tap **Run workflow**.
5. Open the completed green workflow run.
6. Scroll to **Artifacts**.
7. Download **RiverFlow-APK**.
8. GitHub downloads a ZIP; extract it with **My Files**.
9. Inside is `RiverFlow.apk`.

## 4. Install RiverFlow

1. Tap `RiverFlow.apk`.
2. If Android blocks it, tap **Settings** and allow **Install unknown apps** for the browser or My Files app you are using.
3. Install RiverFlow.

## 5. Add the widget

1. Long-press an empty area of the Samsung home screen.
2. Tap **Widgets**.
3. Search for **RiverFlow**.
4. Choose **RiverFlow Compact** or **RiverFlow Large**.
5. Drag the widget onto the home screen.
6. Search for a river and select the gauge you want.

The compact widget shows river name, CFS, water temperature when available, wind and update time. The large widget also adds weather and hatch guidance.
