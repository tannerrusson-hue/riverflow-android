const GROUPS = new Set(['mayfly','caddis','stonefly','midge','terrestrial','sowbug','scud','other']);
const STAGES = {
  mayfly:new Set(['nymph','emerger','dun','spinner']),
  caddis:new Set(['larva','pupa','adult']),
  stonefly:new Set(['nymph','adult']),
  midge:new Set(['larva','pupa','adult']),
  terrestrial:new Set(['ant','beetle','hopper']),
  sowbug:new Set(['adult']),
  scud:new Set(['adult']),
  other:new Set(['unknown'])
};
const SIZES = new Set(['#6–10','#10–14','#14–16','#16–18','#18–20','#20–24','#24–26']);
const COLORS = new Set(['natural','black','red','olive','tan','cream','gray','brown','golden']);

function jsonText(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) return content.map(x => x?.text || x?.content || '').join('');
  return '';
}
function parseJson(text) {
  const cleaned = String(text || '').replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,'').trim();
  try { return JSON.parse(cleaned); } catch {}
  const start = cleaned.indexOf('{'), end = cleaned.lastIndexOf('}');
  if (start >= 0 && end > start) return JSON.parse(cleaned.slice(start,end+1));
  throw new Error('Model did not return valid JSON');
}
function normalize(x) {
  let group = GROUPS.has(x.group) ? x.group : 'other';
  let stage = STAGES[group].has(x.stage) ? x.stage : (group === 'other' ? 'unknown' : [...STAGES[group]][0]);
  let confidence = Math.max(0, Math.min(1, Number(x.confidence) || 0));
  let size = SIZES.has(x.size) ? x.size : '#16–18';
  let color = COLORS.has(x.color) ? x.color : 'natural';
  return {
    group, stage, confidence, size, color,
    commonName: String(x.commonName || ({mayfly:'Mayfly',caddis:'Caddis',stonefly:'Stonefly',midge:'Midge',terrestrial:'Terrestrial',sowbug:'Sowbug',scud:'Scud'}[group] || 'Unknown insect')).slice(0,80),
    evidence: String(x.evidence || '').slice(0,500),
    alternate: String(x.alternate || '').slice(0,120)
  };
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Headers','content-type');
  res.setHeader('Access-Control-Allow-Methods','POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({error:'POST required'});

  const image = req.body?.image;
  const context = req.body?.context || null;
  if (typeof image !== 'string' || !image.startsWith('data:image/') || image.length > 3_500_000) {
    return res.status(400).json({error:'A JPEG/PNG data image under 3.5 MB is required'});
  }
  const token = process.env.AI_GATEWAY_API_KEY || process.env.VERCEL_OIDC_TOKEN;
  if (!token) return res.status(503).json({error:'RiverFlow vision authentication is not configured'});

  const contextText = context ? `\nFishing context (weak prior only; never override the visual evidence): ${JSON.stringify(context)}` : '';
  const prompt = `You are RiverFlow Vision, a conservative aquatic-entomology classifier for fly anglers in Utah, Wyoming, and Idaho.
Analyze the photographed insect. The useful target is insect GROUP and LIFE STAGE, not an overconfident species guess.
Allowed groups: mayfly, caddis, stonefly, midge, terrestrial, sowbug, scud, other.
Allowed stages: mayfly=nymph|emerger|dun|spinner; caddis=larva|pupa|adult; stonefly=nymph|adult; midge=larva|pupa|adult; terrestrial=ant|beetle|hopper; sowbug=adult; scud=adult; other=unknown.
Allowed size buckets: #6–10, #10–14, #14–16, #16–18, #18–20, #20–24, #24–26.
Allowed colors: natural, black, red, olive, tan, cream, gray, brown, golden.
Return ONLY JSON with keys: group, stage, confidence (0 to 1), size, color, commonName, evidence, alternate.
Rules: if the image is blurry, too small, not an insect, or visually ambiguous, lower confidence. Do not infer an exact species from geography alone. Evidence should name 2-4 visible traits. alternate is the most plausible alternative or empty string.${contextText}`;

  try {
    const ai = await fetch('https://ai-gateway.vercel.sh/v1/chat/completions', {
      method:'POST',
      headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json'},
      body:JSON.stringify({
        model:'openai/gpt-5.6-luna',
        messages:[{role:'user',content:[
          {type:'text',text:prompt},
          {type:'image_url',image_url:{url:image,detail:'high'}}
        ]}],
        temperature:0,
        max_tokens:700,
        stream:false
      })
    });
    const data = await ai.json();
    if (!ai.ok) return res.status(502).json({error:data?.error?.message || 'Vision model request failed'});
    const parsed = parseJson(jsonText(data?.choices?.[0]?.message?.content));
    return res.status(200).json(normalize(parsed));
  } catch (e) {
    return res.status(500).json({error:e?.message || 'Vision analysis failed'});
  }
}
