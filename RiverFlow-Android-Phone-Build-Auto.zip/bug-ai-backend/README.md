# RiverFlow Bug AI backend

Deploy this folder as a Vercel project named `riverflow-bug-ai` so its production URL is:

`https://riverflow-bug-ai.vercel.app/api/identify`

The Android/web frontend already points there. The endpoint uses Vercel AI Gateway with either `AI_GATEWAY_API_KEY` or Vercel OIDC (`VERCEL_OIDC_TOKEN`) and a vision-capable model. It returns conservative group/stage/size/color JSON; the frontend keeps fly-pattern selection local so the vision model cannot invent arbitrary fly recommendations.
