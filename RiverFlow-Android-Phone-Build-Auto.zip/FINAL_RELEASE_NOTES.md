# RiverFlow Android v1.9.1

- Migrated direct USGS fallback from retiring WaterServices `/iv` to the modern `latest-continuous` Water Data API.
- Flow-history fallback now uses the modern USGS `continuous` endpoint if the RiverFlow history service is unavailable.
- Search text now searches the full UT/WY/ID/MT catalog regardless of active Big Fish / 20+ / Blue Ribbon chips.
- Search result taps reliably reveal the selected river card above the Android bottom navigation.
- Bottom-right Fly Boxes tab replaced with a permanent **Lower Provo** shortcut to the official CUWCD streamflow page.
- Native Android bridge opens the CUWCD page in the device browser.
- Fly Boxes remain available through Advisor setup/matching flows.
