# RiverFlow Bug Reference Photo Credits

RiverFlow v1.3.6 uses real insect reference photographs from Wikimedia Commons when internet access is available. Each reference card links to its Wikimedia Commons file page for full attribution and license details. Local SVG artwork remains only as a no-network fallback.

Selected photo sources include:
- Blue-Winged Olive / Baetis tricaudatus — Jerry Friedman — CC BY-SA 3.0
- PMD-type / Ephemerella — Judy Gallagher — CC BY 2.0
- Western Green Drake / Drunella grandis larva — Aiva Noringseth — CC BY 4.0
- Trico / Tricorythodes — Bob Henricks — CC BY-SA 2.0
- Callibaetis — Robert Webster / xpda — CC BY-SA 4.0
- Paraleptophlebia — StreamsProject / Bob Henricks — CC BY-SA 3.0
- Seedskadee caddisfly adult — Tom Koerner / U.S. Fish & Wildlife Service — Public Domain
- Spotted Sedge / Hydropsyche-type adult — Bruce Marlin — CC BY-SA 2.5
- October Caddis / Dicosmoecus larva — Bob Henricks — CC BY-SA 2.0
- Caddis adult — Ben Sale — CC BY 2.0
- Caddis pupa — Waldemar Paetz — CC BY-SA 4.0
- Bloodworm / Chironomid larva — Bill Kasman — CC0
- Chironomid larva — Pjt56 — CC BY 4.0
- Chironomus plumosus pupa — Tytiuk & Zakharchuk — CC BY 4.0
- Adult midge macro — Irina Petrova — CC BY 4.0
- Buzzer / adult Chironomid — Simon Johnston — CC BY-SA 2.0
- Chironomid swarm — Simon Johnston — CC BY-SA 2.0
