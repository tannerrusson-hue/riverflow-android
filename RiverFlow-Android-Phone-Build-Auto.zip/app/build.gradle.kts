plugins { id("com.android.application") }

android {
    namespace = "com.riverflow.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.riverflow.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 180
        versionName = "1.8.0"
    }

    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
