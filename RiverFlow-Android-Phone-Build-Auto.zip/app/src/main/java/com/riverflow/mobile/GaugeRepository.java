package com.riverflow.mobile;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

final class GaugeRepository {
    static final String GAUGE_API = "https://riverflow-v2-gauges.vercel.app/api/gauges";
    static final String WEATHER_API = "https://riverflow-v2-weather.vercel.app/api/weather";

    private GaugeRepository() {}

    static List<Gauge> fetchGauges() throws Exception {
        try {
            JSONObject root = getJson(GAUGE_API);
            JSONArray array = root.getJSONArray("gauges");
            List<Gauge> out = parseRiverFlowGauges(array);
            if (!out.isEmpty()) return out;
        } catch (Exception ignored) {}
        return fetchModernUsgsGauges();
    }

    private static List<Gauge> parseRiverFlowGauges(JSONArray array) throws Exception {
        List<Gauge> out = new ArrayList<>(array.length());
        for (int i = 0; i < array.length(); i++) {
            JSONObject g = array.getJSONObject(i);
            Double tempF = g.isNull("tempF") ? null : g.optDouble("tempF");
            Double tempC = g.isNull("tempC") ? null : g.optDouble("tempC");
            out.add(new Gauge(g.getString("id"), g.optString("state", ""),
                    g.optString("name", "River gauge").trim(), g.optDouble("cfs", 0),
                    tempF, tempC, g.optDouble("lat", 0), g.optDouble("lng", 0),
                    g.optString("time", "")));
        }
        return out;
    }

    private static List<Gauge> fetchModernUsgsGauges() throws Exception {
        Map<String, Gauge> merged = new HashMap<>();
        fetchModernState("UT", "49", merged);
        fetchModernState("WY", "56", merged);
        fetchModernState("ID", "16", merged);
        fetchModernState("MT", "30", merged);
        if (merged.isEmpty()) throw new IllegalStateException("USGS Water Data API returned no live gauges");
        return new ArrayList<>(merged.values());
    }

    private static void fetchModernState(String state, String stateCode, Map<String, Gauge> out) throws Exception {
        String url = "https://api.waterdata.usgs.gov/ogcapi/v0/collections/latest-continuous/items"
                + "?f=json&agency_code=USGS&state_code=" + URLEncoder.encode(stateCode, "UTF-8")
                + "&site_type_code=ST&parameter_code=00060&limit=10000";
        JSONObject root = getJson(url);
        JSONArray features = root.optJSONArray("features");
        if (features == null) return;
        long now = System.currentTimeMillis();
        for (int i = 0; i < features.length(); i++) {
            JSONObject feature = features.optJSONObject(i);
            if (feature == null) continue;
            JSONObject p = feature.optJSONObject("properties");
            JSONObject geom = feature.optJSONObject("geometry");
            JSONArray coords = geom == null ? null : geom.optJSONArray("coordinates");
            if (p == null || coords == null || coords.length() < 2) continue;
            String id = p.optString("monitoring_location_number", "");
            if (id.isEmpty()) id = p.optString("monitoring_location_id", "").replace("USGS-", "");
            String time = p.optString("time", "");
            double cfs;
            try { cfs = Double.parseDouble(p.optString("value", "")); } catch (Exception e) { continue; }
            if (id.isEmpty() || !Double.isFinite(cfs) || cfs < 0) continue;
            double lng = coords.optDouble(0, Double.NaN), lat = coords.optDouble(1, Double.NaN);
            if (!Double.isFinite(lat) || !Double.isFinite(lng)) continue;
            Gauge old = out.get(id);
            if (old != null && old.time != null && old.time.compareTo(time) > 0) continue;
            out.put(id, new Gauge(id, state, p.optString("monitoring_location_name", id).trim(),
                    cfs, null, null, lat, lng, time));
        }
    }

    static WeatherNow fetchWeather(double lat, double lng) throws Exception {
        String url = WEATHER_API + "?lat=" + URLEncoder.encode(String.valueOf(lat), "UTF-8")
                + "&lng=" + URLEncoder.encode(String.valueOf(lng), "UTF-8");
        JSONObject root = getJson(url);
        JSONArray days = root.optJSONArray("days");
        if (days == null || days.length() == 0) return WeatherNow.EMPTY;
        JSONObject d = days.getJSONObject(0);
        return new WeatherNow(
                d.optInt("high", Integer.MIN_VALUE),
                d.optInt("low", Integer.MIN_VALUE),
                d.optInt("precip", 0),
                d.optString("windDirection", ""),
                d.optString("windSpeed", ""),
                d.optString("forecast", "")
        );
    }

    private static JSONObject getJson(String urlString) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(18000);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "RiverFlow-Android/1.0");
        try {
            int code = c.getResponseCode();
            InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String body = read(in);
            if (code < 200 || code >= 300) throw new IllegalStateException("HTTP " + code + ": " + body);
            return new JSONObject(body);
        } finally {
            c.disconnect();
        }
    }

    private static String read(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    static final class WeatherNow {
        static final WeatherNow EMPTY = new WeatherNow(Integer.MIN_VALUE, Integer.MIN_VALUE, 0, "", "", "");
        final int high;
        final int low;
        final int precip;
        final String windDirection;
        final String windSpeed;
        final String forecast;

        WeatherNow(int high, int low, int precip, String windDirection, String windSpeed, String forecast) {
            this.high = high;
            this.low = low;
            this.precip = precip;
            this.windDirection = windDirection;
            this.windSpeed = windSpeed;
            this.forecast = forecast;
        }
    }
}
