package com.riverflow.mobile;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class RiverRefreshJob extends JobService {
    private static final int PERIODIC_JOB = 4101;
    private static final int NOW_JOB = 4102;
    private volatile boolean stopped;

    static void schedulePeriodic(Context c) {
        JobScheduler js = c.getSystemService(JobScheduler.class);
        JobInfo info = new JobInfo.Builder(PERIODIC_JOB, new ComponentName(c, RiverRefreshJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPeriodic(30 * 60 * 1000L)
                .setPersisted(true)
                .build();
        js.schedule(info);
    }

    static void scheduleNow(Context c) {
        JobScheduler js = c.getSystemService(JobScheduler.class);
        JobInfo info = new JobInfo.Builder(NOW_JOB, new ComponentName(c, RiverRefreshJob.class))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setMinimumLatency(0)
                .setOverrideDeadline(3000)
                .build();
        js.schedule(info);
    }

    @Override public boolean onStartJob(JobParameters params) {
        stopped = false;
        new Thread(() -> {
            try { refreshAll(); } catch (Exception ignored) {}
            jobFinished(params, false);
        }, "RiverFlow-refresh").start();
        return true;
    }

    @Override public boolean onStopJob(JobParameters params) {
        stopped = true;
        return true;
    }

    private void refreshAll() throws Exception {
        int[] compact = AppWidgetManager.getInstance(this).getAppWidgetIds(new ComponentName(this, CompactRiverWidgetProvider.class));
        int[] large = AppWidgetManager.getInstance(this).getAppWidgetIds(new ComponentName(this, LargeRiverWidgetProvider.class));
        if (compact.length + large.length == 0) return;

        List<Gauge> gauges = GaugeRepository.fetchGauges();
        Map<String, Gauge> byId = new HashMap<>();
        for (Gauge g : gauges) byId.put(g.id, g);
        refreshIds(compact, byId);
        refreshIds(large, byId);
    }

    private void refreshIds(int[] ids, Map<String, Gauge> byId) {
        for (int widgetId : ids) {
            if (stopped) return;
            WidgetPrefs.Data old = WidgetPrefs.load(this, widgetId);
            if (old == null) continue;
            Gauge g = byId.get(old.gaugeId);
            if (g != null) WidgetPrefs.saveGauge(this, widgetId, g);
            WidgetPrefs.Data d = WidgetPrefs.load(this, widgetId);
            if (d != null && d.lat != 0 && d.lng != 0) {
                try { WidgetPrefs.saveWeather(this, widgetId, GaugeRepository.fetchWeather(d.lat, d.lng)); }
                catch (Exception ignored) {}
            }
            WidgetRenderer.updateOne(this, widgetId);
        }
    }
}
