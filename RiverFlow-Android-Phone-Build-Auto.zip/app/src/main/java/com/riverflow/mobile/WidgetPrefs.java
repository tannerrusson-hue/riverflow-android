package com.riverflow.mobile;

import android.content.Context;
import android.content.SharedPreferences;

final class WidgetPrefs {
    private static final String PREFS = "riverflow_widgets";
    private WidgetPrefs() {}

    static void saveGauge(Context c, int id, Gauge g) {
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putString(k(id,"id"), g.id);
        e.putString(k(id,"name"), g.name);
        e.putString(k(id,"state"), g.state);
        e.putString(k(id,"cfs"), String.valueOf(g.cfs));
        e.putString(k(id,"lat"), String.valueOf(g.lat));
        e.putString(k(id,"lng"), String.valueOf(g.lng));
        if (g.tempF == null) e.remove(k(id,"tempF")); else e.putString(k(id,"tempF"), String.valueOf(g.tempF));
        e.putLong(k(id,"updated"), System.currentTimeMillis());
        e.apply();
    }

    static void saveWeather(Context c, int id, GaugeRepository.WeatherNow w) {
        SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putInt(k(id,"high"), w.high);
        e.putInt(k(id,"low"), w.low);
        e.putInt(k(id,"precip"), w.precip);
        e.putString(k(id,"windDir"), w.windDirection);
        e.putString(k(id,"windSpeed"), w.windSpeed);
        e.putString(k(id,"forecast"), w.forecast);
        e.putLong(k(id,"updated"), System.currentTimeMillis());
        e.apply();
    }

    static Data load(Context c, int id) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String gaugeId = p.getString(k(id,"id"), null);
        if (gaugeId == null) return null;
        return new Data(
                gaugeId,
                p.getString(k(id,"name"), "RiverFlow"),
                p.getString(k(id,"state"), ""),
                d(p.getString(k(id,"cfs"), "0")),
                p.contains(k(id,"tempF")) ? d(p.getString(k(id,"tempF"), "0")) : null,
                d(p.getString(k(id,"lat"), "0")),
                d(p.getString(k(id,"lng"), "0")),
                p.getInt(k(id,"high"), Integer.MIN_VALUE),
                p.getInt(k(id,"low"), Integer.MIN_VALUE),
                p.getInt(k(id,"precip"), 0),
                p.getString(k(id,"windDir"), ""),
                p.getString(k(id,"windSpeed"), ""),
                p.getString(k(id,"forecast"), ""),
                p.getLong(k(id,"updated"), 0L)
        );
    }

    static void delete(Context c, int id) {
        SharedPreferences p = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SharedPreferences.Editor e = p.edit();
        String prefix = id + "_";
        for (String key : p.getAll().keySet()) if (key.startsWith(prefix)) e.remove(key);
        e.apply();
    }

    private static String k(int id, String field) { return id + "_" + field; }
    private static double d(String s) { try { return Double.parseDouble(s); } catch (Exception e) { return 0; } }

    static final class Data {
        final String gaugeId, name, state, windDir, windSpeed, forecast;
        final double cfs, lat, lng;
        final Double tempF;
        final int high, low, precip;
        final long updated;
        Data(String gaugeId, String name, String state, double cfs, Double tempF, double lat, double lng,
             int high, int low, int precip, String windDir, String windSpeed, String forecast, long updated) {
            this.gaugeId=gaugeId; this.name=name; this.state=state; this.cfs=cfs; this.tempF=tempF;
            this.lat=lat; this.lng=lng; this.high=high; this.low=low; this.precip=precip;
            this.windDir=windDir; this.windSpeed=windSpeed; this.forecast=forecast; this.updated=updated;
        }
    }
}
