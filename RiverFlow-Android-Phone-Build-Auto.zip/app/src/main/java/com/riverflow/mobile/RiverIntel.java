package com.riverflow.mobile;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

final class RiverIntel {
    static final class Profile {
        final String label;
        final boolean blue;
        final int trophy;
        final boolean trophyVerified;
        final int[] peak;
        Profile(String label, boolean blue, int trophy, boolean trophyVerified, int... peak) {
            this.label=label;
            this.blue=blue;
            this.trophy=trophy;
            this.trophyVerified=trophyVerified;
            this.peak=peak;
        }
    }

    private static final Map<String,Profile> P = new HashMap<>();
    static {
        // Trophy ratings are intentionally conservative. trophyVerified=true requires
        // agency survey/record/management evidence of genuinely large fish in the reach/system.
        add("10155200","Middle Provo · Heber",true,3,false,5,6,7,9,10);
        add("10155500","Middle Provo · Charleston",true,3,false,4,5,6,7,9,10);
        add("09234500","Green River · Greendale",true,4,false,3,4,5,6,9,10,11);

        add("13011000","Snake River · Moran",true,3,false,6,7,8,9,10);
        add("13013650","Snake River · Moose",true,3,false,6,7,8,9,10);
        add("13018750","Snake River · Jackson",true,3,false,6,7,8,9,10);
        add("13022500","Snake River · Alpine",true,3,false,6,7,8,9,10);
        add("06218500","Wind River · Dubois",true,3,false,6,7,8,9);
        add("13027500","Salt River · Alpine",true,3,false,6,7,8,9);
        add("06623800","Encampment River · Upper",true,3,false,5,6,9,10);
        add("09196000","New Fork · Pinedale",true,4,false,6,7,8,9,10);
        add("09205000","New Fork · Big Piney",false,4,false,6,7,8,9,10);

        add("13190500","South Fork Boise · Dam",true,5,true,6,7,8,9,10);
        add("13050500","Henrys Fork · St. Anthony",false,5,true,5,6,7,9,10,11);
        add("13046000","Henrys Fork · Ashton",false,5,true,5,6,7,8,9,10);
        add("13042500","Henrys Fork · Island Park",false,4,true,6,7,8,9,10);
        add("13032500","South Fork Snake · Irwin",false,5,true,6,7,8,9,10);
        add("13037500","South Fork Snake · Heise",false,5,true,6,7,8,9,10);
        add("13150430","Silver Creek · Picabo",false,4,false,6,7,8,9,10);
        add("12414500","St. Joe River · Calder",false,3,false,6,7,8,9);
    }

    private static void add(String id,String label,boolean blue,int trophy,boolean trophyVerified,int... peak){
        P.put(id,new Profile(label,blue,trophy,trophyVerified,peak));
    }

    static Profile get(String id){return P.get(id);}
    static String displayName(Gauge g){Profile p=get(g.id);return p==null?g.name:p.label;}

    static int score(Gauge g){
        Profile p=get(g.id);
        int n=42;
        if(g.tempF==null)n+=3;
        else if(g.tempF<=45)n+=2;
        else if(g.tempF<=60)n+=18;
        else if(g.tempF<=64)n+=16;
        else if(g.tempF<=67)n+=8;
        else if(g.tempF<70)n-=2;
        else if(g.tempF<=72)n-=28;
        else n-=45;

        if(p!=null){
            n+=5;
            if(p.blue)n+=6;
            if(p.trophyVerified)n+=2; // trophy status should not dominate "best fishing now"
            int m=Calendar.getInstance().get(Calendar.MONTH)+1;
            boolean hit=false,near=false;
            for(int x:p.peak){
                if(x==m)hit=true;
                int diff=Math.abs(x-m);
                if(diff==1||diff==11)near=true;
            }
            n+=hit?13:near?6:-4;
        }
        if(g.cfs<=0)n-=25;
        return Math.max(5,Math.min(98,n));
    }

    static String badges(String id){
        Profile p=get(id);
        if(p==null)return "";
        StringBuilder s=new StringBuilder();
        if(p.blue)s.append("◆ BLUE");
        if(p.trophyVerified){
            if(s.length()>0)s.append(" · ");
            s.append("🏆 VERIFIED BIG");
        } else if(p.trophy>=4){
            if(s.length()>0)s.append(" · ");
            s.append("BIG-FISH POTENTIAL");
        }
        return s.toString();
    }
}
