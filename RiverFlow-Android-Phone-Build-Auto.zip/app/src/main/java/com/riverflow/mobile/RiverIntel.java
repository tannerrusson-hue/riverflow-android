package com.riverflow.mobile;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

final class RiverIntel {
    static final class Profile {
        final String label;
        final boolean blue;
        final int trophy;
        final int[] peak;
        Profile(String label, boolean blue, int trophy, int... peak) {
            this.label=label; this.blue=blue; this.trophy=trophy; this.peak=peak;
        }
    }
    private static final Map<String,Profile> P = new HashMap<>();
    static {
        add("10155200","Middle Provo · Heber",true,4,5,6,7,9,10);
        add("10155500","Middle Provo · Charleston",true,4,4,5,6,7,9,10);
        add("09234500","Green River · Greendale",true,5,3,4,5,6,9,10,11);
        add("13011000","Snake River · Moran",true,4,6,7,8,9,10);
        add("13013650","Snake River · Moose",true,4,6,7,8,9,10);
        add("13018750","Snake River · Jackson",true,4,6,7,8,9,10);
        add("13022500","Snake River · Alpine",true,4,6,7,8,9,10);
        add("06218500","Wind River · Dubois",true,3,6,7,8,9);
        add("13027500","Salt River · Alpine",true,3,6,7,8,9);
        add("06623800","Encampment River · Upper",true,3,5,6,9,10);
        add("09196000","New Fork · Pinedale",true,4,6,7,8,9,10);
        add("09205000","New Fork · Big Piney",false,4,6,7,8,9,10);
        add("13190500","South Fork Boise · Dam",true,5,6,7,8,9,10);
        add("13050500","Henrys Fork · St. Anthony",false,5,5,6,7,9,10,11);
        add("13046000","Henrys Fork · Ashton",false,5,5,6,7,8,9,10);
        add("13042500","Henrys Fork · Island Park",false,4,6,7,8,9,10);
        add("13150430","Silver Creek · Picabo",false,4,6,7,8,9,10);
        add("12414500","St. Joe River · Calder",false,3,6,7,8,9);
    }
    private static void add(String id,String label,boolean blue,int trophy,int... peak){P.put(id,new Profile(label,blue,trophy,peak));}
    static Profile get(String id){return P.get(id);}
    static String displayName(Gauge g){Profile p=get(g.id);return p==null?g.name:p.label;}
    static int score(Gauge g){
        Profile p=get(g.id); int n=42;
        if(g.tempF==null)n+=5; else if(g.tempF<=45)n+=3; else if(g.tempF<=64)n+=20; else if(g.tempF<=67)n+=12; else if(g.tempF<70)n+=2; else if(g.tempF<=72)n-=24; else n-=40;
        if(p!=null){n+=5;if(p.blue)n+=12;if(p.trophy>=4)n+=(p.trophy-3)*3;int m=Calendar.getInstance().get(Calendar.MONTH)+1;boolean hit=false,near=false;for(int x:p.peak){if(x==m)hit=true;if(Math.abs(x-m)==1||Math.abs(x-m)==11)near=true;}n+=hit?16:near?8:-3;}
        if(g.cfs<=0)n-=25;
        return Math.max(5,Math.min(99,n));
    }
    static String badges(String id){Profile p=get(id);if(p==null)return "";StringBuilder s=new StringBuilder();if(p.blue)s.append("◆ BLUE");if(p.trophy>=4){if(s.length()>0)s.append(" · ");s.append("🏆 ").append(p.trophy).append("/5");}return s.toString();}
}
