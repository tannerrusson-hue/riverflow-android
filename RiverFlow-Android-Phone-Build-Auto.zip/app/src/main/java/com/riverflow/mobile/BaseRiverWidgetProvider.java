package com.riverflow.mobile;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

public abstract class BaseRiverWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) WidgetRenderer.updateOne(context, id);
        RiverRefreshJob.schedulePeriodic(context);
        RiverRefreshJob.scheduleNow(context);
    }

    @Override public void onDeleted(Context context, int[] ids) {
        for (int id : ids) WidgetPrefs.delete(context, id);
    }

    @Override public void onEnabled(Context context) {
        RiverRefreshJob.schedulePeriodic(context);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (WidgetRenderer.ACTION_REFRESH.equals(intent.getAction())) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) WidgetRenderer.updateOne(context, id);
            RiverRefreshJob.scheduleNow(context);
        }
    }
}
