package com.riverflow.mobile;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.Locale;

final class WidgetRenderer {
    static final String ACTION_REFRESH = "com.riverflow.mobile.REFRESH_WIDGET";
    private WidgetRenderer() {}

    static void updateOne(Context c, int widgetId) {
        AppWidgetManager awm = AppWidgetManager.getInstance(c);
        AppWidgetProviderInfo info = awm.getAppWidgetInfo(widgetId);
        boolean large = info != null && info.provider != null && info.provider.getClassName().contains("LargeRiverWidgetProvider");
        int layout = large ? R.layout.widget_large : R.layout.widget_compact;
        RemoteViews v = new RemoteViews(c.getPackageName(), layout);
        WidgetPrefs.Data d = WidgetPrefs.load(c, widgetId);

        if (d == null) {
            v.setTextViewText(R.id.river_name, "RiverFlow");
            v.setTextViewText(R.id.state_line, "Tap to choose a river");
            v.setTextViewText(R.id.cfs, "-- CFS");
            v.setTextViewText(R.id.temp, "Water --");
            v.setTextViewText(R.id.wind, "Wind --");
            v.setTextViewText(R.id.updated, "Open RiverFlow to configure");
            if (large) {
                v.setTextViewText(R.id.weather, "--");
                v.setTextViewText(R.id.hatch, "Hatch: --");
            }
            awm.updateAppWidget(widgetId, v);
            return;
        }

        v.setTextViewText(R.id.river_name, prettyName(d.name));
        v.setTextViewText(R.id.state_line, d.state + " · USGS " + d.gaugeId);
        v.setTextViewText(R.id.cfs, formatFlow(d.cfs) + " CFS");
        v.setTextViewText(R.id.temp, d.tempF == null ? "Water --" : "Water " + Math.round(d.tempF) + "°F");
        String wind = (d.windDir + " " + d.windSpeed).trim();
        v.setTextViewText(R.id.wind, wind.isEmpty() ? "Wind unavailable" : "Wind " + wind + " · rain " + d.precip + "%");
        v.setTextViewText(R.id.updated, "Updated " + ago(d.updated) + " · tap for full river view");
        if (large) {
            String weather = d.high == Integer.MIN_VALUE ? "--" : d.high + "° / " + (d.low == Integer.MIN_VALUE ? "--" : d.low + "°");
            v.setTextViewText(R.id.weather, weather);
            v.setTextViewText(R.id.hatch, "Hatch: " + hatch(d.name, d.state));
        }

        Intent open = new Intent(c, MainActivity.class);
        open.setData(Uri.parse("riverflow://gauge/" + d.gaugeId));
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, widgetId, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, openPi);

        ComponentName provider = info != null ? info.provider : new ComponentName(c, large ? LargeRiverWidgetProvider.class : CompactRiverWidgetProvider.class);
        Intent refresh = new Intent(ACTION_REFRESH);
        refresh.setComponent(provider);
        refresh.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent refreshPi = PendingIntent.getBroadcast(c, 100000 + widgetId, refresh, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.refresh, refreshPi);
        awm.updateAppWidget(widgetId, v);
    }

    private static String formatFlow(double v) {
        if (v >= 10000) return String.format(Locale.US, "%.1fk", v/1000d);
        if (v >= 1000) return String.format(Locale.US, "%,.0f", v);
        if (v >= 100) return String.format(Locale.US, "%.0f", v);
        if (v >= 10) return String.format(Locale.US, "%.1f", v);
        return String.format(Locale.US, "%.2f", v);
    }

    private static String prettyName(String s) {
        if (s == null || s.trim().isEmpty()) return "RiverFlow";
        String n = s.trim().replace(" RIV ", " RIVER ").replace(" NR ", " near ").replace(" BL ", " below ");
        if (n.length() > 38) n = n.substring(0, 37) + "…";
        return n;
    }

    private static String ago(long time) {
        if (time <= 0) return "just now";
        long m = Math.max(0, (System.currentTimeMillis() - time) / 60000L);
        if (m < 1) return "now";
        if (m < 60) return m + "m ago";
        return (m/60) + "h ago";
    }

    static String hatch(String name, String state) {
        String n = name == null ? "" : name.toUpperCase(Locale.US);
        int m = Calendar.getInstance().get(Calendar.MONTH) + 1;
        if (n.contains("PROVO RIV")) {
            if (m == 8) return "PMD · Caddis · Yellow Sally";
            if (m >= 6 && m <= 7) return "PMD · Caddis · Stoneflies";
            if (m == 9) return "PMD · Caddis · BWO";
            if (m == 10 || m == 11) return "BWO · Midges";
            if (m >= 3 && m <= 5) return "BWO · Midges · Caddis";
            return "Midges · BWO";
        }
        if (m <= 2) return "Midges";
        if (m <= 4) return "BWO · Midges";
        if (m == 5) return "BWO · Caddis";
        if (m == 6) return "PMD · Caddis · Stoneflies";
        if (m == 7) return "PMD · Caddis · Terrestrials";
        if (m == 8) return "WY".equals(state) ? "PMD · Trico · Hopper" : "PMD · Caddis · Terrestrials";
        if (m == 9) return "Trico · BWO · Terrestrials";
        if (m == 10) return "BWO · Caddis · Midges";
        return "Midges · BWO";
    }
}
