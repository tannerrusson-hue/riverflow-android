package com.riverflow.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public final class MainActivity extends Activity {
    private static final String HOME = "https://riverflow-ut-wy.vercel.app";
    private WebView web;
    private String pendingGauge;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(6,23,28));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        s.setSupportZoom(false);

        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String host = u.getHost();
                if (host != null && (host.equals("riverflow-ut-wy.vercel.app") || host.endsWith("riverflow-v2-assets.vercel.app") || host.endsWith("riverflow-v2-style.vercel.app"))) return false;
                startActivity(new Intent(Intent.ACTION_VIEW, u));
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (pendingGauge != null && pendingGauge.matches("\\d+")) {
                    String id = pendingGauge;
                    pendingGauge = null;
                    String js = "(function(){var n=0,t=setInterval(function(){var b=document.querySelector('[data-o=\"" + id + "\"]');if(b){clearInterval(t);b.click()}else if(++n>60){clearInterval(t)}},250)})()";
                    view.evaluateJavascript(js, null);
                }
            }
        });
        loadFromIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadFromIntent(intent);
    }

    private void loadFromIntent(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        String gauge = null;
        if (data != null && "riverflow".equals(data.getScheme()) && "gauge".equals(data.getHost())) {
            String path = data.getPath();
            if (path != null && path.length() > 1) gauge = path.substring(1);
        }
        pendingGauge = gauge;
        String url = gauge == null ? HOME : HOME + "/?gauge=" + Uri.encode(gauge);
        web.loadUrl(url);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
