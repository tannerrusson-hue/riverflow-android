package com.riverflow.mobile;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.InputStream;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final String APP_HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + APP_HOST + "/assets/index.html";
    private static final int REQ_LOCATION = 701;
    private WebView web;
    private LocationManager locationManager;
    private LocationListener oneShotListener;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(6,23,28));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        s.setSupportZoom(false);

        web.addJavascriptInterface(new NativeBridge(), "RiverFlowNative");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost()) && u.getPath() != null && u.getPath().startsWith("/assets/")) {
                    String asset = u.getPath().substring("/assets/".length());
                    try {
                        InputStream in = MainActivity.this.getAssets().open(asset);
                        String mime = asset.endsWith(".js") ? "application/javascript" : asset.endsWith(".css") ? "text/css" : "text/html";
                        return new WebResourceResponse(mime, "UTF-8", in);
                    } catch (Exception ignored) {}
                }
                return super.shouldInterceptRequest(view, request);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (APP_HOST.equals(u.getHost())) return false;
                String host = u.getHost();
                if (host != null && (host.endsWith("riverflow-v2-gauges.vercel.app") ||
                        host.endsWith("riverflow-v2-history.vercel.app") ||
                        host.endsWith("riverflow-v2-weather.vercel.app"))) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                return true;
            }
        });
        loadFromIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        loadFromIntent(intent);
    }

    private void loadFromIntent(Intent intent) {
        Uri data = intent == null ? null : intent.getData();
        String gauge = null;
        if (data != null && "riverflow".equals(data.getScheme()) && "gauge".equals(data.getHost())) {
            String path = data.getPath();
            if (path != null && path.length() > 1) gauge = path.substring(1);
        }
        web.loadUrl(gauge == null ? HOME : HOME + "?gauge=" + Uri.encode(gauge));
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestRiverLocation() {
        if (!hasLocationPermission()) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
            return;
        }
        locateNow();
    }

    @SuppressWarnings("MissingPermission")
    private void locateNow() {
        try {
            locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            if (locationManager == null) { sendLocationError("Location service unavailable"); return; }

            Location best = null;
            String[] providers = new String[]{LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
            for (String provider : providers) {
                try {
                    Location l = locationManager.getLastKnownLocation(provider);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (Exception ignored) {}
            }
            if (best != null) sendLocation(best);
            final boolean hadBest = best != null;

            oneShotListener = new LocationListener() {
                @Override public void onLocationChanged(Location location) {
                    if (location != null) sendLocation(location);
                    stopLocationUpdates();
                }
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
            };

            boolean requested = false;
            try {
                if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    locationManager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, oneShotListener, Looper.getMainLooper());
                    requested = true;
                }
            } catch (Exception ignored) {}
            if (!requested) {
                try {
                    if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, oneShotListener, Looper.getMainLooper());
                        requested = true;
                    }
                } catch (Exception ignored) {}
            }
            if (!requested && best == null) sendLocationError("Turn on Location, then try Nearby again");
            handler.postDelayed(() -> {
                if (oneShotListener != null) {
                    stopLocationUpdates();
                    if (!hadBest) sendLocationError("Couldn’t get your location. Try again outdoors or enable Location.");
                }
            }, 9000L);
        } catch (Throwable t) {
            sendLocationError("Couldn’t get your location");
        }
    }

    @SuppressWarnings("MissingPermission")
    private void stopLocationUpdates() {
        if (locationManager != null && oneShotListener != null) {
            try { locationManager.removeUpdates(oneShotListener); } catch (Exception ignored) {}
        }
        oneShotListener = null;
    }

    private void sendLocation(Location l) {
        if (web == null || l == null) return;
        final String js = String.format(Locale.US,
                "window.RiverFlowLocation&&window.RiverFlowLocation(%.7f,%.7f,%.1f);",
                l.getLatitude(), l.getLongitude(), l.hasAccuracy() ? l.getAccuracy() : 0f);
        web.post(() -> web.evaluateJavascript(js, null));
    }

    private void sendLocationError(String message) {
        if (web == null) return;
        String safe = message == null ? "Location unavailable" : message.replace("\\", "\\\\").replace("'", "\\'");
        web.post(() -> web.evaluateJavascript("window.RiverFlowLocationError&&window.RiverFlowLocationError('" + safe + "');", null));
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION) {
            if (hasLocationPermission()) locateNow();
            else sendLocationError("Location permission is off. Enable it in RiverFlow app permissions to use Nearby.");
        }
    }

    private final class NativeBridge {
        @JavascriptInterface public void requestLocation() { runOnUiThread(MainActivity.this::requestRiverLocation); }
        @JavascriptInterface public void openAppSettings() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {}
            });
        }
    }

    @Override protected void onDestroy() {
        stopLocationUpdates();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
