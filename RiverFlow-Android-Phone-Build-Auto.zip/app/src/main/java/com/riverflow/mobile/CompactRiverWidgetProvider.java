package com.riverflow.mobile;
public final class CompactRiverWidgetProvider extends BaseRiverWidgetProvider {}
