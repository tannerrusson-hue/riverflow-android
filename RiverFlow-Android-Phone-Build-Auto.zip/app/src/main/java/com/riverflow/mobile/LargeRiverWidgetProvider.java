package com.riverflow.mobile;
public final class LargeRiverWidgetProvider extends BaseRiverWidgetProvider {}
