package com.riverflow.mobile;

final class Gauge {
    final String id;
    final String state;
    final String name;
    final double cfs;
    final Double tempF;
    final Double tempC;
    final double lat;
    final double lng;
    final String time;

    Gauge(String id, String state, String name, double cfs, Double tempF, Double tempC,
          double lat, double lng, String time) {
        this.id = id;
        this.state = state;
        this.name = name;
        this.cfs = cfs;
        this.tempF = tempF;
        this.tempC = tempC;
        this.lat = lat;
        this.lng = lng;
        this.time = time;
    }
}
