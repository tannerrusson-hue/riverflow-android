package com.riverflow.mobile;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class WidgetConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private final List<Gauge> all = new ArrayList<>();
    private final List<Gauge> shown = new ArrayList<>();
    private GaugeAdapter adapter;
    private TextView status;
    private EditText search;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            widgetId = resolveWidgetId(getIntent());
            if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
                showWidgetIdError();
                return;
            }
            buildUi();
            seedRecommendedRivers();
            loadGauges();
        } catch (Throwable t) {
            showFatal("Picker setup error", t);
        }
    }

    private int resolveWidgetId(Intent intent) {
        if (intent != null) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) return id;
            Uri data = intent.getData();
            if (data != null && "riverflow".equals(data.getScheme()) && "widget-config".equals(data.getHost())) {
                try {
                    List<String> seg = data.getPathSegments();
                    if (!seg.isEmpty()) {
                        int parsed = Integer.parseInt(seg.get(seg.size() - 1));
                        if (parsed != AppWidgetManager.INVALID_APPWIDGET_ID) return parsed;
                    }
                } catch (Throwable ignored) {}
            }
        }

        AppWidgetManager awm = AppWidgetManager.getInstance(this);
        int[] compact = awm.getAppWidgetIds(new ComponentName(this, CompactRiverWidgetProvider.class));
        int[] large = awm.getAppWidgetIds(new ComponentName(this, LargeRiverWidgetProvider.class));
        for (int id : compact) if (WidgetPrefs.load(this, id) == null) return id;
        for (int id : large) if (WidgetPrefs.load(this, id) == null) return id;
        if (compact.length == 1 && large.length == 0) return compact[0];
        if (large.length == 1 && compact.length == 0) return large[0];
        return AppWidgetManager.INVALID_APPWIDGET_ID;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), 0);
        root.setBackgroundColor(Color.rgb(6,23,28));

        TextView title = text("Choose a river", 27, Color.rgb(245,251,252), true);
        TextView sub = text("Recommended trout rivers first. Search any live USGS gauge in Utah, Wyoming or Idaho.", 12, Color.rgb(141,166,173), false);
        sub.setPadding(0, dp(5), 0, dp(14));
        root.addView(title);
        root.addView(sub);

        search = new EditText(this);
        search.setHint("Search Provo, Henrys Fork, Snake…");
        search.setHintTextColor(Color.rgb(96,126,134));
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setPadding(dp(13), 0, dp(13), 0);
        search.setBackgroundColor(Color.rgb(12,37,45));
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        status = text("Recommended rivers ready · loading all live gauges…", 11, Color.rgb(141,166,173), false);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        ListView list = new ListView(this);
        list.setDividerHeight(1);
        list.setDivider(null);
        list.setCacheColorHint(Color.TRANSPARENT);
        adapter = new GaugeAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            if (position >= 0 && position < shown.size()) choose(shown.get(position));
        });
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { safeFilter(s == null ? "" : s.toString()); }
            public void afterTextChanged(Editable e) {}
        });
        setContentView(root);
    }

    private void seedRecommendedRivers() {
        all.clear();
        addFallback("10155500", "UT", "PROVO RIVER NEAR CHARLESTON");
        addFallback("10155200", "UT", "PROVO RIV AT RIV ROAD BRIDGE NR HEBER CITY");
        addFallback("09234500", "UT", "GREEN RIVER NEAR GREENDALE");
        addFallback("13011000", "WY", "SNAKE RIVER NEAR MORAN");
        addFallback("13013650", "WY", "SNAKE RIVER AT MOOSE");
        addFallback("13018750", "WY", "SNAKE RIVER BELOW FLAT CREEK, NEAR JACKSON");
        addFallback("13022500", "WY", "SNAKE RIVER ABOVE RESERVOIR, NEAR ALPINE");
        addFallback("09196000", "WY", "NEW FORK RIVER ABOVE PINE CR, NR PINEDALE");
        addFallback("09205000", "WY", "NEW FORK RIVER NEAR BIG PINEY");
        addFallback("13027500", "WY", "SALT RIVER ABOVE RESERVOIR, NEAR ETNA");
        addFallback("06623800", "WY", "ENCAMPMENT RIVER AB HOG PARK CR, NR ENCAMPMENT");
        addFallback("13190500", "ID", "SF BOISE RIVER AT ANDERSON RANCH DAM");
        addFallback("13032500", "ID", "SNAKE RIVER NR IRWIN");
        addFallback("13037500", "ID", "SNAKE RIVER NR HEISE");
        addFallback("13046000", "ID", "HENRYS FORK NR ASHTON");
        addFallback("13042500", "ID", "HENRYS FORK NR ISLAND PARK");
        addFallback("13050500", "ID", "HENRYS FORK AT ST ANTHONY");
        addFallback("13150430", "ID", "SILVER CREEK AT SPORTSMAN ACCESS NR PICABO");
        addFallback("12414500", "ID", "ST JOE RIVER AT CALDER");
        safeFilter("");
    }

    private void addFallback(String id, String state, String name) {
        all.add(new Gauge(id, state, name, 0d, null, null, 0d, 0d, ""));
    }

    private void loadGauges() {
        new Thread(() -> {
            try {
                List<Gauge> result = GaugeRepository.fetchGauges();
                Collections.sort(result, (a,b) -> {
                    int d = RiverIntel.score(b) - RiverIntel.score(a);
                    if (d != 0) return d;
                    return RiverIntel.displayName(a).compareToIgnoreCase(RiverIntel.displayName(b));
                });
                runOnUiThread(() -> {
                    try {
                        all.clear();
                        all.addAll(result);
                        safeFilter(search == null ? "" : search.getText().toString());
                        status.setText("Live gauges loaded · recommended rivers first");
                    } catch (Throwable t) {
                        status.setText("Live gauges loaded, but list refresh hit an issue. Recommended rivers are still available.");
                    }
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    if (status != null) status.setText("Live gauge refresh unavailable · recommended rivers still work");
                });
            }
        }, "RiverFlow-config").start();
    }

    private void safeFilter(String q) {
        try {
            filter(q);
        } catch (Throwable t) {
            if (status != null) status.setText("Search issue: " + shortMessage(t));
        }
    }

    private void filter(String q) {
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.US);
        shown.clear();
        int cap = needle.isEmpty() ? 160 : 120;
        for (Gauge g : all) {
            if (g == null) continue;
            String hay = String.valueOf(g.name) + " " + String.valueOf(g.state) + " " + String.valueOf(g.id);
            if (needle.isEmpty() || hay.toLowerCase(Locale.US).contains(needle)) shown.add(g);
            if (shown.size() >= cap) break;
        }
        if (adapter != null) adapter.notifyDataSetChanged();
        if (status != null && !all.isEmpty()) {
            if (needle.isEmpty() && all.size() <= 20) status.setText("Recommended rivers ready · loading all live gauges…");
            else status.setText(shown.size() + " shown · tap a river to select");
        }
    }

    private void choose(Gauge g) {
        try {
            WidgetPrefs.saveGauge(this, widgetId, g);
            WidgetRenderer.updateOne(this, widgetId);
            RiverRefreshJob.schedulePeriodic(this);
            RiverRefreshJob.scheduleNow(this);
            finish();
        } catch (Throwable t) {
            status.setText("Couldn’t save this river: " + shortMessage(t));
        }
    }

    private void showWidgetIdError() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(6,23,28));
        TextView title = text("Widget connection lost", 24, Color.rgb(245,251,252), true);
        TextView body = text("RiverFlow couldn't identify which home-screen widget you tapped. Remove that widget, add it once more, then tap it to choose a river.", 13, Color.rgb(141,166,173), false);
        body.setGravity(Gravity.CENTER);
        body.setPadding(0, dp(12), 0, 0);
        root.addView(title);
        root.addView(body);
        setContentView(root);
    }

    private void showFatal(String titleText, Throwable t) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(6,23,28));
        TextView title = text(titleText, 22, Color.WHITE, true);
        TextView body = text(shortMessage(t), 13, Color.rgb(141,166,173), false);
        body.setPadding(0, dp(12), 0, 0);
        root.addView(title);
        root.addView(body);
        setContentView(root);
    }

    private String shortMessage(Throwable t) {
        if (t == null) return "Unknown error";
        String m = t.getMessage();
        if (m == null || m.trim().isEmpty()) m = t.getClass().getSimpleName();
        if (m.length() > 180) m = m.substring(0, 180);
        return m;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private final class GaugeAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Gauge getItem(int position) { return position >= 0 && position < shown.size() ? shown.get(position) : null; }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            try {
                RowHolder h;
                LinearLayout row;
                if (convertView instanceof LinearLayout && convertView.getTag() instanceof RowHolder) {
                    row = (LinearLayout) convertView;
                    h = (RowHolder) convertView.getTag();
                } else {
                    row = new LinearLayout(WidgetConfigActivity.this);
                    row.setOrientation(LinearLayout.VERTICAL);
                    row.setPadding(dp(14), dp(11), dp(14), dp(11));
                    row.setMinimumHeight(dp(64));
                    row.setBackgroundColor(Color.rgb(6,23,28));
                    TextView a = text("", 14, Color.rgb(245,251,252), true);
                    TextView b = text("", 10, Color.rgb(141,166,173), false);
                    b.setPadding(0, dp(3), 0, 0);
                    row.addView(a, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    row.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    h = new RowHolder(a,b);
                    row.setTag(h);
                }

                Gauge g = getItem(position);
                if (g == null) {
                    h.title.setText("River");
                    h.detail.setText("Unavailable");
                    return row;
                }
                h.title.setText(RiverIntel.displayName(g));
                String temp = g.tempF == null ? "" : " · " + Math.round(g.tempF) + "°F water";
                String badges = RiverIntel.badges(g.id);
                String flow = g.cfs > 0 ? " · " + Math.round(g.cfs) + " CFS" : "";
                h.detail.setText(g.state + " · Score " + RiverIntel.score(g) + (badges.isEmpty()?"":" · "+badges) + flow + temp);
                return row;
            } catch (Throwable t) {
                TextView safe = text("River option unavailable", 13, Color.WHITE, false);
                safe.setPadding(dp(14), dp(14), dp(14), dp(14));
                safe.setBackgroundColor(Color.rgb(6,23,28));
                return safe;
            }
        }
    }

    private static final class RowHolder {
        final TextView title;
        final TextView detail;
        RowHolder(TextView title, TextView detail) { this.title = title; this.detail = detail; }
    }
}
