package com.riverflow.mobile;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class WidgetConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
    private final List<Gauge> all = new ArrayList<>();
    private final List<Gauge> shown = new ArrayList<>();
    private GaugeAdapter adapter;
    private TextView status;
    private EditText search;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }
        buildUi();
        loadGauges();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), 0);
        root.setBackgroundColor(Color.rgb(6,23,28));

        TextView title = text("Choose a river", 27, Color.rgb(245,251,252), true);
        TextView sub = text("Each widget can watch a different USGS gauge in Utah, Wyoming or Idaho.", 12, Color.rgb(141,166,173), false);
        sub.setPadding(0, dp(5), 0, dp(14));
        root.addView(title);
        root.addView(sub);

        search = new EditText(this);
        search.setHint("Search Provo, Henrys Fork, Snake…");
        search.setHintTextColor(Color.rgb(96,126,134));
        search.setTextColor(Color.WHITE);
        search.setSingleLine(true);
        search.setPadding(dp(13), 0, dp(13), 0);
        search.setBackgroundColor(Color.rgb(12,37,45));
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        status = text("Loading live gauges…", 11, Color.rgb(141,166,173), false);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        ListView list = new ListView(this);
        list.setDividerHeight(1);
        list.setCacheColorHint(Color.TRANSPARENT);
        adapter = new GaugeAdapter(shown);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> choose(shown.get(position)));
        root.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) { filter(s.toString()); }
            public void afterTextChanged(Editable e) {}
        });
        setContentView(root);
    }

    private void loadGauges() {
        new Thread(() -> {
            try {
                List<Gauge> result = GaugeRepository.fetchGauges();
                Collections.sort(result, Comparator.comparing(g -> g.name));
                runOnUiThread(() -> {
                    all.clear(); all.addAll(result);
                    filter(search.getText().toString());
                    status.setText(all.size() + " live gauges · tap one to add the widget");
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Couldn’t load gauges. Check internet and try again."));
            }
        }, "RiverFlow-config").start();
    }

    private void filter(String q) {
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.US);
        shown.clear();
        for (Gauge g : all) {
            if (needle.isEmpty() || (g.name + " " + g.state + " " + g.id).toLowerCase(Locale.US).contains(needle)) shown.add(g);
            if (shown.size() >= 120 && !needle.isEmpty()) break;
        }
        adapter.notifyDataSetChanged();
        if (!all.isEmpty()) status.setText(shown.size() + " matching gauges · tap to select");
    }

    private void choose(Gauge g) {
        WidgetPrefs.saveGauge(this, widgetId, g);
        WidgetRenderer.updateOne(this, widgetId);
        RiverRefreshJob.schedulePeriodic(this);
        RiverRefreshJob.scheduleNow(this);
        Intent result = new Intent();
        result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        setResult(RESULT_OK, result);
        finish();
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        return t;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private final class GaugeAdapter extends ArrayAdapter<Gauge> {
        GaugeAdapter(List<Gauge> items) { super(WidgetConfigActivity.this, android.R.layout.simple_list_item_2, items); }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            View v = super.getView(position, convertView, parent);
            Gauge g = getItem(position);
            TextView a = v.findViewById(android.R.id.text1);
            TextView b = v.findViewById(android.R.id.text2);
            a.setTextColor(Color.rgb(245,251,252)); a.setTextSize(14); a.setText(g.name);
            b.setTextColor(Color.rgb(141,166,173)); b.setTextSize(10);
            String temp = g.tempF == null ? "" : " · " + Math.round(g.tempF) + "°F water";
            b.setText(g.state + " · " + WidgetRenderer.hatch(g.name, g.state) + " · " + Math.round(g.cfs) + " CFS" + temp);
            v.setBackgroundColor(Color.rgb(6,23,28));
            return v;
        }
    }
}
