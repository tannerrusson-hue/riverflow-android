let G=[],S=null,Q='',ST='ALL',MODE='recommended',PLAN='now',FO=false,V='list',D=7,Y=0,M=null,STALE=false,CACHE_TIME=0;
let F=JSON.parse(localStorage.getItem('riverflow-favorites')||'[]'),WX={},LOC=null,LOCATING=false,LOCERR='';
let RADIUS=Number(localStorage.getItem('riverflow-radius')||100);
let APP_TAB=localStorage.getItem('riverflow-main-tab')||'rivers';
let BUG_VIEW='identify',BUG_CAMERA='',BUG_STREAM=null,BUG_PHOTO='',BUG_KIND='',BUG_STAGE='',BUG_SIZE='#16–18',BUG_COLOR='natural',BUG_RESULT=null,BUG_NOTE='',BUG_ANALYZING=false,BUG_AI_RESULT=null;
const BUG_API='https://riverflow-bug-ai.vercel.app/api/identify';
const BOX_META_KEY='riverflow-flyboxes-v2',BOX_ACTIVE_KEY='riverflow-active-flybox',BOX_DB_NAME='riverflow-local',BOX_DB_STORE='flybox-images';
let BOX_STORAGE_NOTE='',BOX_IMAGE_CACHE={};
function boxUid(){return'box-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8)}
function loadBoxes(){
 try{
  let a=JSON.parse(localStorage.getItem(BOX_META_KEY)||'null');
  if(Array.isArray(a)&&a.length)return a.map((b,i)=>({id:b.id||boxUid(),name:b.name||`Fly Box ${i+1}`,flies:Array.isArray(b.flies)?b.flies:[],image:''}));
 }catch{}
 try{
  let legacy=JSON.parse(localStorage.getItem('riverflow-flybox')||'null');
  if(legacy&&(legacy.image||legacy.flies?.length))return[{id:boxUid(),name:'Fly Box 1',flies:Array.isArray(legacy.flies)?legacy.flies:[],image:'',legacyImage:legacy.image||''}];
 }catch{}
 return[{id:boxUid(),name:'Fly Box 1',flies:[],image:''}];
}
let BOXES=loadBoxes();
let ACTIVE_BOX_ID=localStorage.getItem(BOX_ACTIVE_KEY)||BOXES[0].id;
let BOX=BOXES.find(b=>b.id===ACTIVE_BOX_ID)||BOXES[0];ACTIVE_BOX_ID=BOX.id;
let BOX_PICK={pattern:'Pheasant Tail',size:'#16',color:'natural'};
function boxDb(){
 return new Promise((resolve,reject)=>{try{let r=indexedDB.open(BOX_DB_NAME,1);r.onupgradeneeded=()=>{let db=r.result;if(!db.objectStoreNames.contains(BOX_DB_STORE))db.createObjectStore(BOX_DB_STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)}catch(e){reject(e)}})
}
async function putBoxImage(id,data){
 BOX_IMAGE_CACHE[id]=data||'';
 try{let db=await boxDb();await new Promise((resolve,reject)=>{let t=db.transaction(BOX_DB_STORE,'readwrite'),q=t.objectStore(BOX_DB_STORE).put(data,id);q.onsuccess=()=>resolve();q.onerror=()=>reject(q.error)});db.close();try{localStorage.removeItem('riverflow-box-photo-'+id)}catch{};return true}
 catch(e){BOX_STORAGE_NOTE='Indexed photo storage is unavailable; RiverFlow is using a smaller local fallback for this box.';try{localStorage.setItem('riverflow-box-photo-'+id,data||'')}catch{};return false}
}
async function getBoxImage(id){
 if(BOX_IMAGE_CACHE[id])return BOX_IMAGE_CACHE[id];
 try{let db=await boxDb(),v=await new Promise((resolve,reject)=>{let t=db.transaction(BOX_DB_STORE,'readonly'),q=t.objectStore(BOX_DB_STORE).get(id);q.onsuccess=()=>resolve(q.result||'');q.onerror=()=>reject(q.error)});db.close();if(v){BOX_IMAGE_CACHE[id]=v;return v}}catch{}
 try{let v=localStorage.getItem('riverflow-box-photo-'+id)||'';BOX_IMAGE_CACHE[id]=v;return v}catch{return''}
}
async function deleteBoxImage(id){
 delete BOX_IMAGE_CACHE[id];try{localStorage.removeItem('riverflow-box-photo-'+id)}catch{};try{let db=await boxDb();await new Promise((resolve,reject)=>{let t=db.transaction(BOX_DB_STORE,'readwrite'),q=t.objectStore(BOX_DB_STORE).delete(id);q.onsuccess=()=>resolve();q.onerror=()=>reject(q.error)});db.close()}catch{}
}
function saveBoxes(){
 let clean=BOXES.map(b=>({id:b.id,name:b.name||'Fly Box',flies:Array.isArray(b.flies)?b.flies:[]}));
 localStorage.setItem(BOX_META_KEY,JSON.stringify(clean));localStorage.setItem(BOX_ACTIVE_KEY,ACTIVE_BOX_ID)
}
function activateBox(id){let b=BOXES.find(x=>x.id===id);if(!b)return;ACTIVE_BOX_ID=id;BOX=b;localStorage.setItem(BOX_ACTIVE_KEY,id)}
function mappedCount(){return BOXES.reduce((n,b)=>n+(b.flies?.length||0),0)}
function allBoxFlies(){return BOXES.flatMap(b=>(b.flies||[]).map((f,i)=>({...f,i,boxId:b.id,boxName:b.name,boxImage:b.image||BOX_IMAGE_CACHE[b.id]||''})))}
function rankBoxFlies(recs,limit=5){return allBoxFlies().map(f=>({...f,score:scoreBoxFly(f,recs)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,limit)}
function newBox(){let b={id:boxUid(),name:`Fly Box ${BOXES.length+1}`,flies:[],image:''};BOXES.push(b);activateBox(b.id);saveBoxes();draw()}
async function removeActiveBox(){
 let id=BOX.id;if(!confirm(`Delete ${BOX.name||'this fly box'} and its saved photo?`))return;await deleteBoxImage(id);BOXES=BOXES.filter(b=>b.id!==id);if(!BOXES.length)BOXES=[{id:boxUid(),name:'Fly Box 1',flies:[],image:''}];activateBox(BOXES[0].id);saveBoxes();draw()
}
async function initFlyBoxes(){
 try{await navigator.storage?.persist?.()}catch{}
 for(let b of BOXES){
  if(b.legacyImage){await putBoxImage(b.id,b.legacyImage);delete b.legacyImage}
  b.image=await getBoxImage(b.id)
 }
 saveBoxes();localStorage.removeItem('riverflow-flybox');activateBox(ACTIVE_BOX_ID)
}
const FLY_CATALOG=[
 ['Pheasant Tail',['mayfly','nymph']],['Frenchie',['mayfly','nymph']],['Perdigon',['mayfly','nymph']],['PMD Split Case',['mayfly','pmd','nymph']],['Green Drake Nymph',['mayfly','green-drake','nymph']],['Green Drake Parachute',['mayfly','green-drake','dun','dry']],
 ['RS2',['mayfly','midge','emerger']],["Barr's Emerger",['mayfly','emerger','pmd','bwo']],['Sparkle Dun',['mayfly','dun','dry']],
 ['Comparadun',['mayfly','dun','dry']],['Parachute Adams',['mayfly','dun','dry']],['Rusty Spinner',['mayfly','spinner','dry']],
 ['Green Caddis Larva',['caddis','larva','nymph']],['Caddis Pupa',['caddis','pupa','emerger']],['X-Caddis',['caddis','adult','dry','emerger']],
 ['Elk Hair Caddis',['caddis','adult','dry']],["Pat's Rubber Legs",['stonefly','nymph']],['20 Incher',['stonefly','nymph']],
 ['Chubby Chernobyl',['stonefly','adult','terrestrial','dry']],['Stimulator',['stonefly','adult','dry']],['Zebra Midge',['midge','larva','pupa']],
 ['WD-40',['midge','mayfly','emerger']],["Griffith's Gnat",['midge','adult','dry']],['Midge Cluster',['midge','adult','dry']],
 ['Parachute Ant',['terrestrial','ant','dry']],['Foam Beetle',['terrestrial','beetle','dry']],['Morrish Hopper',['terrestrial','hopper','dry']],
 ['Woolly Bugger',['streamer','leech','attractor']],['Sowbug',['sowbug','nymph']],['Scud',['scud','nymph']]
].map(x=>({name:x[0],tags:x[1]}));
const BUG_TYPES={
 mayfly:{label:'Mayfly',symbol:'〰',hint:'2–3 tails · upright sail-like wings',stages:['nymph','emerger','dun','spinner'],colors:['olive','tan','cream','gray','brown']},
 caddis:{label:'Caddis',symbol:'⌁',hint:'tent-shaped wings · no long tails',stages:['larva','pupa','adult'],colors:['olive','tan','cream','brown','black']},
 stonefly:{label:'Stonefly',symbol:'ϟ',hint:'2 tails · long body · wings fold flat',stages:['nymph','adult'],colors:['black','brown','golden','olive']},
 midge:{label:'Midge',symbol:'·',hint:'tiny mosquito-like insect · 2 wings',stages:['larva','pupa','adult'],colors:['black','red','olive','cream']},
 terrestrial:{label:'Terrestrial',symbol:'✦',hint:'ant · beetle · hopper · land insect',stages:['ant','beetle','hopper'],colors:['black','brown','tan','olive']},
 sowbug:{label:'Sowbug',symbol:'◒',hint:'flattened gray aquatic crustacean · segmented body',stages:['adult'],colors:['gray','tan','natural']},
 scud:{label:'Scud',symbol:'◜',hint:'curved shrimp-like aquatic crustacean',stages:['adult'],colors:['olive','gray','tan','natural']},
 other:{label:'Other / not sure',symbol:'?',hint:'Use guided comparison',stages:['unknown'],colors:['natural']}
};
const BUG_GUIDE={
 mayfly:{
  nymph:[['Pheasant Tail','Best general mayfly nymph'],['Frenchie','Slim fast-sinking option'],['Perdigon','Deep / fast water']],
  emerger:[['RS2','Top emerger choice'],["Barr's Emerger",'Match PMD/BWO emergence'],['WD-40','Small subsurface emerger']],
  dun:[['Sparkle Dun','Low-riding natural profile'],['Comparadun','Selective-trout dry'],['Parachute Adams','Easy-to-see backup']],
  spinner:[['Rusty Spinner','Spent-wing mayfly match'],['Parachute Adams','Backup dry']]
 },
 caddis:{
  larva:[['Green Caddis Larva','Match subsurface larvae'],['Pheasant Tail','Simple backup nymph']],
  pupa:[['Caddis Pupa','Start here during emergence'],['X-Caddis','Fish in/near film']],
  adult:[['X-Caddis','Low-riding adult / emerger'],['Elk Hair Caddis','High-floating adult']]
 },
 stonefly:{
  nymph:[["Pat's Rubber Legs",'Best all-around stonefly nymph'],['20 Incher','Heavy natural option']],
  adult:[['Chubby Chernobyl','Large buoyant adult/attractor'],['Stimulator','Classic stonefly dry']]
 },
 midge:{
  larva:[['Zebra Midge','Start subsurface'],['WD-40','Slim alternative']],
  pupa:[['Zebra Midge','Suspended pupa imitation'],['RS2','Excellent tiny emerger']],
  adult:[["Griffith's Gnat",'Cluster / adult dry'],['Midge Cluster','Match clustered adults']]
 },
 terrestrial:{
  ant:[['Parachute Ant','Excellent ant match'],['Foam Beetle','Backup small terrestrial']],
  beetle:[['Foam Beetle','Start here'],['Parachute Ant','Smaller backup']],
  hopper:[['Morrish Hopper','Natural hopper profile'],['Chubby Chernobyl','Buoyant hopper/attractor']]
 },
 sowbug:{adult:[['Sowbug','Direct match for aquatic sowbugs'],['Pheasant Tail','Slim backup nymph']]},
 scud:{adult:[['Scud','Direct match for freshwater scuds'],['Sowbug','Useful close-profile backup']]}
};
const $=s=>document.querySelector(s), E=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const N=n=>n>=1000?(n/1000).toFixed(1)+'k':Math.round(n).toLocaleString();
const AGE=t=>{if(!t)return'unknown';let m=Math.max(0,Math.round((Date.now()-new Date(t))/60000));return m<60?m+'m ago':m<1440?Math.round(m/60)+'h ago':Math.round(m/1440)+'d ago'};
const DAYS=t=>Math.max(0,Math.floor((Date.now()-new Date(t+'T12:00:00'))/86400000));
const MONTH=()=>new Date().getMonth()+1;

const SRC={
 utBlue:'https://wildlife.utah.gov/blueribbon',
 wyBlue:'https://wgfd.wyo.gov/aquatic-habitat/stream-categorization',
 wyHeat:'https://wgfd.wyo.gov/fishing-boating/fishing-heat',
 idSFSnake:'https://idfg.idaho.gov/article/georgia-angler-reels-new-idaho-catch-and-release-record-brown-trout',
 idHenrys:'https://idfg.idaho.gov/blog/2022/06/trout-density-henrys-fork-snake-river',
 idBox:'https://idfg.idaho.gov/blog/2021/06/rainbow-trout-population-box-canyon-remains-strong',
 idSFBoise:'https://idfg.idaho.gov/blog/2021/06/wild-trout-and-wildfire-monitoring-trout-populations-south-fork-boise-river-after',
 idSouthFork:'https://idfg.idaho.gov/fish/south-fork-snake'
};

// Reach-specific profiles. A trophyVerified river needs agency survey/record/management evidence of truly large fish.
const P={
 '10155200':{title:'Middle Provo · Heber',blue:true,agency:'Utah DWR',agencyUrl:SRC.utBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'12–18 in common class',plus:'20+ possible, not treated as common',species:'Brown trout · Mountain whitefish',best:['Dry flies','Consistent trout','Close to Wasatch'],peak:[5,6,7,9,10],trophySeason:'Fall',tactics:'Low-light streamers · deeper nymph lanes · structure',why:'Excellent quality fishery, but RiverFlow does not label it a verified giant-trout destination without reach-specific size data.'},
 '10155500':{title:'Middle Provo · Charleston',blue:true,agency:'Utah DWR',agencyUrl:SRC.utBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'12–18 in common class',plus:'20+ possible, not treated as common',species:'Brown trout · Mountain whitefish',best:['PMD fishing','Numbers of trout','Year-round option'],peak:[4,5,6,7,9,10],trophySeason:'Fall',tactics:'Streamers at low light · sowbugs/PMDs · deeper banks',why:'Strong all-around trout water; Blue Ribbon quality is not being confused with trophy-fish frequency.'},
 '09234500':{title:'Green River · Greendale',blue:true,agency:'Utah DWR',agencyUrl:SRC.utBlue,trophy:4,trophyVerified:false,confidence:'Moderate',typical:'Quality tailwater trout',plus:'Strong big-fish potential; exact frequency varies by reach',species:'Rainbow · Brown · Cutthroat',best:['Sight fishing','Tailwater consistency','Quality trout'],peak:[3,4,5,6,9,10,11],trophySeason:'Spring & fall',tactics:'Streamers · scuds/midges · structure and low light',why:'Flagship Blue Ribbon tailwater with legitimate big-fish reputation, but RiverFlow reserves “Verified Giant Fish” for stronger size-survey evidence.'},
 '13011000':{title:'Snake River · Moran',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Quality cutthroat fishery',plus:'20+ possible',species:'Snake River cutthroat · Whitefish',best:['Cutthroat','Dry flies','Scenery'],peak:[6,7,8,9,10],trophySeason:'Late summer & fall',tactics:'Banks with foam dries · riffles · low-light streamers',why:'Wyoming Blue Ribbon reach; primarily ranked for excellent trout production and dry-fly quality rather than giant-fish frequency.',heat:true},
 '13013650':{title:'Snake River · Moose',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Quality cutthroat fishery',plus:'20+ possible',species:'Snake River cutthroat · Whitefish',best:['Dry flies','Cutthroat','Float fishing'],peak:[6,7,8,9,10],trophySeason:'Late summer & fall',tactics:'Banks · riffle seams · foam/terrestrials',why:'Blue Ribbon reach with excellent seasonal dry-fly opportunity; not presented as a reliable giant-trout river.',heat:true},
 '13018750':{title:'Snake River · Jackson',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Quality cutthroat fishery',plus:'20+ possible',species:'Snake River cutthroat · Whitefish',best:['Cutthroat','Float fishing','Terrestrials'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Banks · side channels · streamers at dawn/dusk',why:'Blue Ribbon reach with strong habitat and seasonal dry-fly fishing.',heat:true},
 '13022500':{title:'Snake River · Alpine',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Quality cutthroat fishery',plus:'20+ possible',species:'Snake River cutthroat · Whitefish',best:['Float fishing','Cutthroat','Fall fishing'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Streamers · deep banks · side channels',why:'Lower end of Wyoming’s Blue Ribbon Snake River corridor.',heat:true},
 '06218500':{title:'Wind River · Dubois',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Mixed-size wild trout',plus:'Occasional larger trout',species:'Rainbow · Brown · Cutthroat',best:['Blue Ribbon','Wading','Mountain setting'],peak:[6,7,8,9],trophySeason:'Late summer',tactics:'Nymph pocket water · terrestrials · deeper bends',why:'High-quality Blue Ribbon trout water; no giant-fish badge without stronger size evidence.'},
 '13027500':{title:'Salt River · Alpine',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Quality wild trout',plus:'Occasional 20+ fish',species:'Cutthroat · Brown · Rainbow',best:['Wading','Dry flies','Blue Ribbon'],peak:[6,7,8,9],trophySeason:'Late summer & fall',tactics:'Undercut banks · hopper/dropper · streamers',why:'Productive Wyoming Blue Ribbon valley river.'},
 '06623800':{title:'Encampment River · Upper',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:3,trophyVerified:false,confidence:'Moderate',typical:'Wild trout; size varies',plus:'Some larger browns',species:'Brown · Rainbow',best:['Blue Ribbon','Pocket water','Solitude'],peak:[5,6,9,10],trophySeason:'Fall',tactics:'Pocket-water nymphing · streamers · cooler windows',why:'Excellent trout production; exact heat advisories are reach-specific, so live temperature matters heavily.'},
 '09196000':{title:'New Fork · Pinedale',blue:true,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:4,trophyVerified:false,confidence:'Moderate',typical:'Quality brown/rainbow trout',plus:'Strong 20+ potential',species:'Brown · Rainbow · Cutthroat',best:['Big trout potential','Float fishing','Blue Ribbon'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Streamers · deep bends · undercut banks',why:'Blue Ribbon New Fork with strong big-trout reputation, but RiverFlow keeps it below verified agency-size fisheries until stronger reach-specific survey evidence is attached.',heat:true},
 '09205000':{title:'New Fork · Big Piney',blue:false,agency:'Wyoming G&F',agencyUrl:SRC.wyBlue,trophy:4,trophyVerified:false,confidence:'Moderate',typical:'Quality brown/rainbow trout',plus:'Strong 20+ potential',species:'Brown · Rainbow · Cutthroat',best:['Big trout potential','Float fishing','Fall fishing'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Streamers · banks · deeper structure',why:'Larger-river habitat and strong trophy reputation; Blue Ribbon designation is kept reach-specific.',heat:true},
 '13190500':{title:'South Fork Boise · Dam',blue:true,agency:'Idaho F&G',agencyUrl:SRC.idSFBoise,trophy:5,trophyVerified:true,confidence:'High',typical:'Strong quality-rainbow fishery',plus:'20+ class supported by trophy-oriented regulations/agency material',species:'Wild Rainbow · Whitefish',best:['Big rainbows','Tailwater','Technical fishing'],peak:[6,7,8,9,10],trophySeason:'Late summer & fall',tactics:'Stoneflies/PMDs · streamers · deep seams · low light',why:'One of RiverFlow’s strongest evidence-backed trophy choices.'},
 '13050500':{title:'Henrys Fork · St. Anthony',blue:false,agency:'Idaho F&G',agencyUrl:SRC.idHenrys,trophy:5,trophyVerified:true,confidence:'High',typical:'Large browns present',plus:'Brown trout to 25 in documented survey work',species:'Brown · Rainbow · Cutthroat',best:['Verified big browns','Technical fishing','Late season'],peak:[5,6,7,9,10,11],trophySeason:'Fall',tactics:'Streamers · deep bends · low-light brown-trout windows',why:'IDFG survey evidence documents genuinely large browns in this reach.'},
 '13046000':{title:'Henrys Fork · Ashton',blue:false,agency:'Idaho F&G',agencyUrl:SRC.idHenrys,trophy:5,trophyVerified:true,confidence:'High',typical:'Quality brown/rainbow trout',plus:'Brown trout to 27 in documented survey work',species:'Brown · Rainbow · Whitefish',best:['Verified big trout','Major hatches','Technical fishing'],peak:[5,6,7,8,9,10],trophySeason:'Fall',tactics:'PMDs/caddis · streamers · structure',why:'IDFG documented a 27-inch brown in the Warm River–Ashton survey reach.'},
 '13042500':{title:'Henrys Fork · Box Canyon',blue:false,agency:'Idaho F&G',agencyUrl:SRC.idBox,trophy:4,trophyVerified:true,confidence:'High',typical:'High-density quality rainbows',plus:'20–21 in fish documented in surveys',species:'Rainbow · Whitefish',best:['Numbers of trout','20+ verified','Technical fishing'],peak:[6,7,8,9,10],trophySeason:'Late summer',tactics:'Match the hatch · nymph seams · structure',why:'IDFG surveys combine very high abundance with fish over 20 inches.'},
 '13032500':{title:'South Fork Snake · Irwin',blue:false,agency:'Idaho F&G',agencyUrl:SRC.idSFSnake,trophy:5,trophyVerified:true,confidence:'High',typical:'Abundant wild trout; large browns present',plus:'30+ browns verified but exceptionally rare',species:'Cutthroat · Brown · Rainbow',best:['Verified giant potential','Wild trout','Float fishing'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Deep structure · streamers · big-river seams · low light',why:'IDFG verified a 30.5-inch catch-and-release record in 2026 and survey fish over 30 inches, while explicitly noting that fish over 25 are rare.'},
 '13037500':{title:'South Fork Snake · Heise',blue:false,agency:'Idaho F&G',agencyUrl:SRC.idSFSnake,trophy:5,trophyVerified:true,confidence:'High',typical:'Abundant wild trout; large browns present',plus:'30+ browns verified but exceptionally rare',species:'Cutthroat · Brown · Rainbow',best:['Verified giant potential','Wild trout','Dry-fly fishing'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Deep structure · streamers · banks · low light',why:'Same South Fork system with agency-verified giant brown-trout potential; giant fish remain rare, not routine.'},
 '13150430':{title:'Silver Creek · Picabo',blue:false,agency:'Idaho F&G',agencyUrl:'https://idfg.idaho.gov/ifwis/fishingplanner/',trophy:4,trophyVerified:false,confidence:'Moderate',typical:'Technical spring-creek trout',plus:'20+ potential',species:'Brown · Rainbow',best:['Technical dries','Sight fishing','Quality trout'],peak:[6,7,8,9,10],trophySeason:'Fall',tactics:'Tricos/PMDs · long leaders · stealth · low light',why:'Excellent spring-creek trophy potential, but RiverFlow does not claim verified giant-fish frequency without stronger size-survey evidence.'},
 '12414500':{title:'St. Joe River · Calder',blue:false,agency:'Idaho F&G',agencyUrl:'https://idfg.idaho.gov/ifwis/fishingplanner/',trophy:3,trophyVerified:false,confidence:'Moderate',typical:'12–16 in common class',plus:'Some larger cutthroat',species:'Westslope cutthroat',best:['Cutthroat','Dry flies','Scenery'],peak:[6,7,8,9],trophySeason:'Late summer',tactics:'Dries · terrestrials · faster oxygenated water',why:'Renowned cutthroat river; RiverFlow prioritizes it for fishing quality rather than trophy size.'}
};

const REPORTS={
 '10155200':{date:'2026-07-28',source:'Trout Bum 2',url:'https://www.troutbum2.com/middle-provo-river-fishing-reports/',rating:4,summary:'Nymphing consistent; PMDs, caddis and midges with dry-fly windows.'},
 '10155500':{date:'2026-07-28',source:'Trout Bum 2',url:'https://www.troutbum2.com/middle-provo-river-fishing-reports/',rating:4,summary:'Good midsummer fishing; PMDs, caddis, midges and terrestrials.'},
 '09234500':{date:'2026-07-28',source:'Trout Bum 2',url:'https://www.troutbum2.com/guide-service/green-river/',rating:4,summary:'PMDs and caddis main hatches; ants useful; flow schedule varies.'},
 '13011000':{date:'2026-07-26',source:'Teton Troutfitters',url:'https://tetontroutfitters.com/river-system/snake-river/',rating:4,summary:'Clear water with PMDs, terrestrials and caddis; float-oriented at summer flows.'},
 '13013650':{date:'2026-07-26',source:'Teton Troutfitters',url:'https://tetontroutfitters.com/river-system/snake-river/',rating:4,summary:'Good clarity at Moose with PMDs, terrestrials and caddis.'},
 '13018750':{date:'2026-07-26',source:'Teton Troutfitters',url:'https://tetontroutfitters.com/river-system/snake-river/',rating:4,summary:'Summer dry-fly program; current heat advisory should be checked.'},
 '13022500':{date:'2026-07-26',source:'Teton Troutfitters',url:'https://tetontroutfitters.com/river-system/snake-river/',rating:4,summary:'Summer dry-fly/terrestrial program; current heat advisory should be checked.'},
 '09196000':{date:'2026-07-22',source:'Two Rivers Fishing Co.',url:'https://tworiversfishing.com/blog/fishing-reports/fishing-report-july-22-2026/',rating:2,summary:'Warmer conditions slowed New Fork; upper sections were the better option and early fishing was emphasized.'},
 '09205000':{date:'2026-07-22',source:'Two Rivers Fishing Co.',url:'https://tworiversfishing.com/blog/fishing-reports/fishing-report-july-22-2026/',rating:2,summary:'Warm-water concern; upper sections favored, with drakes, PMDs and caddis.'},
 '13190500':{date:'2026-07-03',source:'Orvis / local report',url:'https://fishingreports.orvis.com/west/idaho/boise-river',rating:4,summary:'South Fork Boise reported fishing well; big dries and stonefly nymphs.'},
 '13042500':{date:'2026-07-10',source:"Henry's Fork Anglers",url:'https://henrysforkanglers.com/blogs/fishing-reports',rating:4,summary:'Box Canyon reported fishing well with PMDs and lingering golden stones.'},
 '13046000':{date:'2026-07-10',source:"Henry's Fork Anglers",url:'https://henrysforkanglers.com/blogs/fishing-reports',rating:4,summary:'Henrys Fork hatches remained strong; report is now aging.'},
 '13050500':{date:'2026-07-10',source:"Henry's Fork Anglers",url:'https://henrysforkanglers.com/blogs/fishing-reports',rating:4,summary:'Henrys Fork hatches remained strong; report is now aging.'},
 '13032500':{date:'2026-07-20',source:'Orvis / WorldCast Anglers',url:'https://fishingreports.orvis.com/west/idaho/south-fork-of-the-snake-river',rating:4,summary:'Summer levels with Goldens, PMDs, Yellow Sallies and caddis.'},
 '13037500':{date:'2026-07-20',source:'Orvis / WorldCast Anglers',url:'https://fishingreports.orvis.com/west/idaho/south-fork-of-the-snake-river',rating:4,summary:'Summer levels with strong dry, foam and dry-dropper opportunities.'},
 '13150430':{date:'2026-07-26',source:'Fly Fish Food',url:'https://www.flyfishfood.com/blogs/fly-fishing-reports/silver-creek',rating:3,summary:'PMDs, Callibaetis and terrestrials; report warned about warm afternoon water.'},
 '12414500':{date:'2026-08-09',source:'Silver Bow Fly Shop',url:'https://www.silverbowflyshop.com/fishingreports/',rating:3,summary:'Low midsummer flows; mornings below Avery, move upriver for cooler water; caddis and terrestrials.'}
};

const HEAT={
 snake:{date:'2026-07-29',url:SRC.wyHeat,text:'Wyoming G&F issued a July 29 voluntary noon-to-sunrise catch-and-release closure on the Snake River from Yellowstone National Park to Palisades Reservoir. Status can change—open the agency page before fishing.'},
 newfork:{date:'2026-07-23',url:SRC.wyHeat,text:'Wyoming G&F issued a July 23 voluntary noon-to-sunrise catch-and-release closure on the New Fork from Mesa Bridge to its confluence with the Green. Status can change—open the agency page before fishing.'}
};

const prof=g=>P[g.id]||null, report=g=>REPORTS[g.id]||null;
function reportState(r){if(!r)return{label:'No recent local report',cls:'low',age:999};let d=DAYS(r.date);return d<=7?{label:`Fresh report · ${d}d`,cls:'high',age:d}:d<=14?{label:`Recent report · ${d}d`,cls:'high',age:d}:d<=30?{label:`Aging report · ${d}d`,cls:'mid',age:d}:{label:`Stale report · ${d}d`,cls:'low',age:d}}
function heatNote(g){let p=prof(g);if(!p?.heat)return null;if(g.id.startsWith('1301')||g.id==='13022500')return HEAT.snake;if(g.id.startsWith('0919')||g.id==='09205000')return HEAT.newfork;return null}
function tempScore(t){if(t==null)return 3;if(t<42)return 2;if(t<=60)return 18;if(t<=64)return 16;if(t<=67)return 9;if(t<70)return 0;if(t<=72)return-28;return-45}
function seasonal(p,plan=PLAN){if(!p)return 0;let month=MONTH();if(plan==='spring')month=4;if(plan==='summer')month=7;if(plan==='fall')month=10;if(plan==='winter')month=1;let hit=p.peak.includes(month),near=p.peak.some(x=>Math.min(Math.abs(x-month),12-Math.abs(x-month))===1);return hit?13:near?6:-4}
function weatherScore(g){if(!(PLAN==='now'||PLAN==='weekend'))return 0;let d=WX[g.id]?.days?.[PLAN==='weekend'?1:0];if(!d)return 0;let s=0,wind=parseInt(String(d.windSpeed||'').match(/\d+/)?.[0]||0),rain=Number(d.precip||0);if(wind<=8)s+=5;else if(wind>=20)s-=7;else if(wind>=15)s-=3;if(rain>=70)s-=5;else if(rain<=25)s+=2;return s}
function reportScore(g){let r=report(g);if(!r||!(PLAN==='now'||PLAN==='weekend'))return 0;let d=DAYS(r.date),fresh=d<=7?1:d<=14?.75:d<=30?.3:0;return Math.round((r.rating-2.5)*7*fresh)}
function freshnessScore(g){let h=(Date.now()-new Date(g.time))/36e5;if(h<=1)return 5;if(h<=3)return 2;if(h<=12)return-2;return-9}
function SCORE(g){let p=prof(g),n=43+tempScore(g.tempF)+freshnessScore(g)+weatherScore(g)+reportScore(g)+seasonal(p);if(p?.blue)n+=6;if(p?.trophyVerified)n+=2;if(g.cfs<=0)n-=24;let hn=heatNote(g);if(hn&&(PLAN==='now'||PLAN==='weekend')&&g.tempF!=null&&g.tempF>=65)n-=8;return{n:Math.max(5,Math.min(98,Math.round(n)))}}
function CONF(g){let p=prof(g),r=report(g),rs=reportState(r),pts=0,why=[];let h=(Date.now()-new Date(g.time))/36e5;if(h<=2){pts+=2;why.push('live gauge')}else why.push('older gauge');if(g.tempF!=null){pts++;why.push('water temp')}if(p?.agencyUrl){pts+=2;why.push('agency fishery data')}if(p?.trophyVerified){pts++;why.push('verified size evidence')}if(rs.age<=7){pts+=3;why.push('fresh local report')}else if(rs.age<=14){pts+=2;why.push('recent local report')}else if(rs.age<=30){pts++;why.push('aging local report')}if(WX[g.id]){pts++;why.push('forecast')}let label=pts>=8?'High':pts>=5?'Moderate':'Low';return{label,pts,why,report:rs}}
function scoreClass(n){return n>=84?'hot':n>=70?'good':n>=55?'fair':'poor'}
function planLabel(){return({now:'Right now',weekend:'This weekend',spring:'Spring',summer:'Summer',fall:'Fall',winter:'Winter'})[PLAN]}
function hav(a,b,c,d){const R=3958.8,rad=x=>x*Math.PI/180,p1=rad(a),p2=rad(c),dp=rad(c-a),dl=rad(d-b),h=Math.sin(dp/2)**2+Math.cos(p1)*Math.cos(p2)*Math.sin(dl/2)**2;return 2*R*Math.asin(Math.sqrt(h))}
function DIST(g){return LOC&&Number.isFinite(g.lat)&&Number.isFinite(g.lng)?hav(LOC.lat,LOC.lng,g.lat,g.lng):null}
function distText(g){let d=DIST(g);return d==null?'':`${Math.round(d)} mi`}
function likelyFishing(g){if(P[g.id])return true;let n=(g.name||'').toUpperCase();if(/CANAL|DRAIN|SEWAGE|FLOODWAY|SPILLBACK|WASTEWATER|OUTFALL/.test(n))return false;return /RIVER|CREEK|FORK|STREAM/.test(n)}
function baseFiltered(){return G.filter(g=>(ST==='ALL'||g.state===ST)&&(!Q||(`${g.name} ${P[g.id]?.title||''} ${g.id}`).toLowerCase().includes(Q.toLowerCase()))&&(!FO||F.includes(g.id)))}
function LIST(){let a=baseFiltered();if(MODE==='recommended')a=a.filter(g=>P[g.id]);if(MODE==='blue')a=a.filter(g=>P[g.id]?.blue);if(MODE==='trophy')a=a.filter(g=>P[g.id]?.trophyVerified);if(MODE==='nearby')a=a.filter(g=>LOC&&likelyFishing(g)&&DIST(g)<=RADIUS);if(MODE!=='all')a=a.filter(likelyFishing);a.sort((x,y)=>{if(MODE==='nearby'){let ax=SCORE(x).n-Math.min(20,(DIST(x)||0)/18),ay=SCORE(y).n-Math.min(20,(DIST(y)||0)/18);return ay-ax}if(MODE==='trophy'){let pt=(P[y.id]?.trophy||0)-(P[x.id]?.trophy||0);if(pt)return pt}return SCORE(y).n-SCORE(x).n});return a}
function TOP(){let a=G.filter(g=>P[g.id]&&likelyFishing(g)&&(ST==='ALL'||g.state===ST));if(MODE==='blue')a=a.filter(g=>P[g.id].blue);if(MODE==='trophy')a=a.filter(g=>P[g.id].trophyVerified);if(MODE==='nearby')a=a.filter(g=>LOC&&DIST(g)<=RADIUS);a.sort((x,y)=>MODE==='nearby'?(SCORE(y).n-Math.min(20,(DIST(y)||0)/18))-(SCORE(x).n-Math.min(20,(DIST(x)||0)/18)):SCORE(y).n-SCORE(x).n);return a.slice(0,3)}
function why(g){let p=prof(g),r=report(g),rs=reportState(r),a=[];if(g.tempF!=null)a.push(g.tempF<65?`✓ Water ${Math.round(g.tempF)}°F`:g.tempF<68?`△ Water ${Math.round(g.tempF)}°F — warming`:`⚠ Water ${Math.round(g.tempF)}°F`);else a.push('• Water temperature not reported');if(p?.blue)a.push('✓ Verified Blue Ribbon reach');if(p?.trophyVerified)a.push('✓ Agency-backed big-fish evidence');if(r&&rs.age<=30)a.push(`${rs.age<=14?'✓':'△'} ${r.source} report ${rs.age}d old`);else if(r)a.push(`△ Local report is ${rs.age}d old`);else a.push('△ No recent local fishing report');let d=DIST(g);if(d!=null)a.push(`• ${Math.round(d)} mi from you`);if(heatNote(g))a.push('⚠ Agency heat advisory exists — verify exact reach');return a}

function reportBadge(g){let c=CONF(g),r=report(g);return`<div class="intelLine"><span class="confidence ${c.label.toLowerCase()}">Intel ${c.label}</span><span class="reportAge ${c.report.cls}">${E(c.report.label)}</span>${r?`<span>${E(r.source)}</span>`:''}</div>`}
function badges(g){let p=prof(g);return`${p?.blue?'<span class="blue">◆ Blue Ribbon</span>':''}${p?.trophyVerified?'<span class="trophy">🏆 Verified big fish</span>':p?.trophy>=4?'<span class="potential">Big-fish potential</span>':''}`}
function rec(g,i){let p=prof(g),s=SCORE(g),d=distText(g);return`<button class="rec" data-o="${g.id}"><div class="recRank">#${i+1}</div><div class="recBody"><div class="recTop"><div><span class="recName">${E(p?.title||g.name)}</span><div class="recBadges">${badges(g)}</div></div><div class="score ${scoreClass(s.n)}"><b>${s.n}</b><small>/100</small></div></div><div class="recMeta"><span>${N(g.cfs)} CFS</span>${g.tempF!=null?`<span>${Math.round(g.tempF)}°F water</span>`:''}${d?`<span>📍 ${d}</span>`:''}</div>${reportBadge(g)}<div class="recWhy">${E(why(g)[0]||'Live conditions')}</div></div></button>`}
function recommendations(){let t=TOP();if(MODE==='nearby'&&!LOC)return`<section class="recommend"><div class="sectionHead"><div><span class="ey">NEARBY FISHING</span><h2>Find the best rivers around you</h2></div></div><p class="muted big">RiverFlow uses your location only while the app is open. Your exact location is not saved.</p><button id="locate" class="primary">${LOCATING?'Locating…':'Use my location'}</button>${LOCERR?`<div class="locerr">${E(LOCERR)}</div>`:''}</section>`;return`<section class="recommend"><div class="sectionHead"><div><span class="ey">${MODE==='trophy'?'VERIFIED BIG FISH':MODE==='blue'?'BLUE RIBBON PRIORITY':MODE==='nearby'?'BEST NEAR YOU':'BEST RIVERS'}</span><h2>${planLabel()}</h2></div><span class="liveDot">LIVE CONDITIONS</span></div>${t.length?t.map(rec).join(''):'<div class="empty">No profiled rivers match this filter.</div>'}<p class="tiny">Scores combine live conditions, season, weather, verified fishery evidence and report freshness. A score is decision support—not a promise of catching fish.</p></section>`}
function nearbyBar(){if(MODE!=='nearby')return'';return`<section class="nearbar"><div><b>${LOC?`📍 Location active${LOC.acc?` · ±${Math.round(LOC.acc)}m`:''}`:'📍 Location off'}</b><small>Straight-line distance to gauge</small></div><div class="radius">${[25,50,100,200].map(x=>`<button data-radius="${x}" class="${RADIUS===x?'on':''}">${x} mi</button>`).join('')}</div></section>`}
function rows(){let a=LIST();return`<div id="rows"><div class="count"><span>${a.length} rivers/gauges</span><span>${MODE==='all'?'All gauges':'Fishing-focused'}</span></div>${a.slice(0,300).map(g=>{let p=prof(g),s=SCORE(g),d=distText(g);return`<div class="g"><button class="fav ${F.includes(g.id)?'on':''}" data-f="${g.id}">★</button><button class="gm" data-o="${g.id}"><div class="gmain"><h3>${E(p?.title||g.name)}</h3><p><span class="dot"></span>${g.state} · ${AGE(g.time)}${d?` · 📍 ${d}`:''}</p><div class="miniBadges">${p?.blue?'<span>◆ BLUE</span>':''}${p?.trophyVerified?'<span class="gold">🏆 VERIFIED BIG</span>':''}${p&&!p.trophyVerified&&p.trophy>=4?'<span>BIG-FISH POTENTIAL</span>':''}</div></div><div class="rowRight">${p?`<span class="miniScore ${scoreClass(s.n)}">${s.n}</span>`:''}<div class="flow"><b>${N(g.cfs)}</b><span>CFS${g.tempF!=null?` · <i class="temp">${Math.round(g.tempF)}°F</i>`:''}</span></div></div></button></div>`}).join('')||'<div class="empty">No matches.</div>'}</div>`}
function home(){let ut=G.filter(x=>x.state==='UT').length,wy=G.filter(x=>x.state==='WY').length,id=G.filter(x=>x.state==='ID').length;return`<header class="top"><div><div class="brand"><b>≈</b> RiverFlow</div><div class="sub">UTAH · WYOMING · IDAHO</div></div><button id="reload" class="icon">↻</button></header>${mainNav()}${STALE?`<div class="stale">Live USGS refresh is temporarily unavailable. Showing last successful river data from ${new Date(CACHE_TIME).toLocaleString()}.</div>`:''}<section class="hero"><span class="ey">FISHING INTELLIGENCE</span><h1>Know the river.<br><span>Choose smarter.</span></h1><p>Live flow, water temperature, weather, verified trophy evidence, Blue Ribbon reaches, report freshness and nearby fishing.</p><div class="stats"><div><b>${ut}</b><span>Utah gauges</span></div><div><b>${wy}</b><span>Wyoming</span></div><div><b>${id}</b><span>Idaho</span></div></div></section><section class="plan"><span class="section">When are you fishing?</span><div class="chips">${[['now','Right now'],['weekend','This weekend'],['spring','Spring'],['summer','Summer'],['fall','Fall'],['winter','Winter']].map(x=>`<button data-plan="${x[0]}" class="${PLAN===x[0]?'on':''}">${x[1]}</button>`).join('')}</div></section>${recommendations()}<section class="controls"><div class="modeTabs">${[['recommended','🔥 Best'],['nearby','📍 Nearby'],['blue','◆ Blue Ribbon'],['trophy','🏆 Verified Big'],['all','All gauges']].map(x=>`<button data-mode="${x[0]}" class="${MODE===x[0]?'on':''}">${x[1]}</button>`).join('')}</div>${nearbyBar()}<label class="search">⌕<input id="search" placeholder="Search river or gauge" value="${E(Q)}"></label><div class="chips">${[['ALL','All'],['UT','Utah'],['WY','Wyoming'],['ID','Idaho']].map(x=>`<button data-s="${x[0]}" class="${ST===x[0]?'on':''}">${x[1]}</button>`).join('')}<button id="favs" class="${FO?'on':''}">★ Favorites</button></div></section><div class="tabs"><button id="list" class="${V==='list'?'on':''}">List</button><button id="mapbtn" class="${V==='map'?'on':''}">Fishing map</button></div>${V==='list'?rows():`<div class="mapWrap"><div id="map" class="map"></div><div class="legend"><span><i class="mk both"></i> Blue + verified big</span><span><i class="mk blueonly"></i> Blue Ribbon</span><span><i class="mk trophyonly"></i> Verified big fish</span><span><i class="mk normal"></i> Other fishing gauge</span>${LOC?'<span><i class="mk you"></i> You</span>':''}</div></div>`}<section class="official"><div><span class="pill">Lower Provo · Deer Creek</span><h3>Official CUWCD flow</h3><p>Use the water district page when you need the exact release below Deer Creek Dam.</p></div><button id="cuw">Open</button></section><footer>RiverFlow keeps Blue Ribbon status, trophy evidence and current fishing reports separate. Regulations, access and agency advisories can change—verify before fishing.</footer>`}


function mainNav(){return`<nav class="mainNav"><button data-app="rivers" class="${APP_TAB==='rivers'?'on':''}"><span>≈</span><b>River Intel</b></button><button data-app="bugs" class="${APP_TAB==='bugs'?'on':''}"><span>⌁</span><b>Bug ID + FlyBox</b><i>NEW</i></button></nav>`}
function lastRiver(){let id=localStorage.getItem('riverflow-last-gauge');return G.find(x=>x.id===id)||null}
function bugSizeNumber(s){let m=String(s||'').match(/\d+/);return m?+m[0]:18}
function patternTags(name){return FLY_CATALOG.find(x=>x.name===name)?.tags||[]}
function contextRig(type,stage){
 let g=lastRiver(),t=g?.tempF,adult=['dun','spinner','adult','ant','beetle','hopper'].includes(stage);
 if(adult&&!(t!=null&&t<50))return'Start on top. If fish refuse it, drop the second choice 18–30 in below the dry.';
 if(type==='stonefly'&&stage==='nymph')return'Fish near the bottom with enough weight to tick occasionally; focus on seams and banks.';
 if(type==='midge')return'Keep the rig slim. Start 1–3 ft off bottom, then shorten toward the film if fish rise.';
 if(type==='caddis'&&stage==='pupa')return'Swing or lift the pupa through the end of the drift; emerging caddis often move upward.';
 return t!=null&&t<55?'Start subsurface and prioritize depth before changing patterns.':'Start with the closest size/color match, then change stage before making a huge pattern change.';
}
function recommendBug(type=BUG_KIND,stage=BUG_STAGE,size=BUG_SIZE,color=BUG_COLOR){
 let list=BUG_GUIDE[type]?.[stage]||[],g=lastRiver();
 return{type,stage,size,color,flies:list.map((x,i)=>({pattern:x[0],why:x[1],rank:i+1,size,color})),rig:contextRig(type,stage),river:g?prof(g)?.title||g.name:'No river selected'};
}
function noBiteAdvice(r){
 let adult=['dun','spinner','adult','ant','beetle','hopper'].includes(r.stage);
 if(adult)return'No eats? Go one size smaller first. If fish are rising but refusing, switch to an emerger/low-riding pattern before changing insect families.';
 if(r.stage==='nymph'||r.stage==='larva')return'No eats? Fix depth first. Then go one size smaller. Change color only after depth and size are close.';
 if(r.stage==='pupa'||r.stage==='emerger')return'No eats? Fish the pattern higher in the column and add a lift/swing at the end of the drift.';
 return'No eats? Change size and presentation before abandoning a strong hatch match.';
}
function bugContext(){
 let g=lastRiver();if(!g)return`<section class="bugContext"><div><span>RIVER CONTEXT</span><b>No river selected</b><small>Pick a river first for temperature/flow-aware rig advice.</small></div><button data-app="rivers">Choose river</button></section>`;
 let p=prof(g);return`<section class="bugContext active"><div><span>RIVER CONTEXT</span><b>${E(p?.title||g.name)}</b><small>${N(g.cfs)} CFS${g.tempF!=null?` · ${Math.round(g.tempF)}°F water`:''} · ${AGE(g.time)}</small></div><button data-app="rivers">Change</button></section>`;
}
function bugResultCard(r){
 if(!r)return'';
 return`<section class="bugResult glass"><div class="resultTop"><div><span class="pill aqua">MATCH THE HATCH</span><h2>${E(BUG_TYPES[r.type]?.label||'Bug')} · ${E(r.stage)}</h2><p>${E(r.size)} · ${E(r.color)} · ${E(r.river)}</p></div><div class="matchSeal">MATCH</div></div>
 <div class="flyStack">${r.flies.map((f,i)=>`<div class="flyPick rank${i+1}"><div class="flyRank">${i+1}</div><div><b>${E(f.pattern)} ${E(f.size)}</b><span>${E(f.why)}</span></div>${i===0?'<em>START HERE</em>':''}</div>`).join('')||'<div class="empty">Pick a life stage to build fly recommendations.</div>'}</div>
 <div class="rigCallout"><span>RIG / PRESENTATION</span><b>${E(r.rig)}</b></div>
 <div class="noBite"><span>IF NOTHING EATS</span><b>${E(noBiteAdvice(r))}</b></div>
 ${mappedCount()?`<button class="primary glow" id="matchBox">✦ Auto-pick from my ${BOXES.length} ${BOXES.length===1?'box':'boxes'} →</button>`:`<button class="primary ghost" data-bugview="flybox">Set up My Fly Boxes →</button>`}</section>`;
}
function bugTypeCards(){return`<div class="bugTypes">${Object.entries(BUG_TYPES).map(([k,v])=>`<button data-bugtype="${k}" class="${BUG_KIND===k?'on':''}"><span class="bugGlyph">${v.symbol}</span><b>${v.label}</b><small>${v.hint}</small></button>`).join('')}</div>`}
function stageChips(){
 let t=BUG_TYPES[BUG_KIND];if(!t)return'';
 return`<div class="fieldBlock"><span class="section">Life stage</span><div class="chips stageChips">${t.stages.map(s=>`<button data-stage="${s}" class="${BUG_STAGE===s?'on':''}">${s}</button>`).join('')}</div></div>
 <div class="fieldGrid"><label><span>Approx. hook size</span><select id="bugSize">${['#6–10','#10–14','#14–16','#16–18','#18–20','#20–24','#24–26'].map(s=>`<option ${BUG_SIZE===s?'selected':''}>${s}</option>`).join('')}</select></label><label><span>Color</span><select id="bugColor">${t.colors.map(c=>`<option ${BUG_COLOR===c?'selected':''}>${c}</option>`).join('')}</select></label></div>`;
}
function bugPhotoPanel(){
 if(BUG_CAMERA==='bug')return`<section class="cameraStage"><video id="bugVideo" autoplay playsinline muted></video><div class="cameraShade"></div><div class="focusRing"><span>Center one bug</span></div><div class="cameraTop"><button id="cameraClose">×</button><span>BUG CAMERA</span><i>LIVE</i></div><div class="cameraBottom"><button id="cameraGallery">▣</button><button id="cameraShutter" class="shutter"><i></i></button><button disabled>✦</button></div><input id="bugFile" type="file" accept="image/*" capture="environment" hidden></section>`;
 if(BUG_PHOTO)return`<section class="captured glass"><div class="captureImage"><img src="${BUG_PHOTO}" alt="Captured insect"><div class="scanLine"></div></div><div class="captureActions"><button id="retakeBug">Retake</button><button id="clearBug">Clear</button></div></section>`;
 return`<section class="bugCaptureHero"><div class="bugArt"><div class="wing w1"></div><div class="wing w2"></div><div class="bugBody"></div><div class="tail t1"></div><div class="tail t2"></div></div><span class="pill aqua">PHOTO-ASSISTED BUG ID</span><h1>See the hatch.<br><span>Match it.</span></h1><p>Photograph an insect from the water, then RiverFlow turns the ID into fly patterns, size, color and presentation.</p><button id="takeBug" class="cameraCTA"><span>◎</span><div><b>Take Bug Photo</b><small>Use the rear camera</small></div><i>→</i></button><button id="uploadBug" class="textBtn">Choose existing photo</button><input id="bugFile" type="file" accept="image/*" capture="environment" hidden></section>`;
}
function aiBugCard(){
 let a=BUG_AI_RESULT;if(!a)return'';
 let pct=Math.round((Number(a.confidence)||0)*100),cls=pct>=80?'high':pct>=55?'moderate':'low';
 return`<section class="aiBugCard glass"><div class="sectionHead"><div><span class="ey">RIVERFLOW VISION</span><h2>${E(a.commonName||BUG_TYPES[a.group]?.label||'Possible match')}</h2></div><span class="confidence ${cls}">${pct}% confidence</span></div><div class="aiMeta"><span>${E(BUG_TYPES[a.group]?.label||a.group||'Unknown')}</span><span>${E(a.stage||'stage unknown')}</span><span>${E(a.size||'size unknown')}</span></div><p>${E(a.evidence||'Photo characteristics were compared with common fly-fishing insect groups.')}</p>${pct<55?'<div class="aiCaution">Low confidence — RiverFlow is not treating this as a confirmed ID. Correct the group/stage below before building a fly match.</div>':''}</section>`;
}

function queueAutoBugAnalysis(){
 if(!BUG_PHOTO)return;
 BUG_NOTE='';BUG_AI_RESULT=null;BUG_RESULT=null;
 setTimeout(()=>analyzeBugPhoto(true),120);
}

async function analyzeBugPhoto(auto=false){
 if(!BUG_PHOTO||BUG_ANALYZING)return;BUG_ANALYZING=true;BUG_NOTE=auto?'RiverFlow Vision is identifying the insect…':'';draw();
 try{
  let g=lastRiver(),controller=new AbortController(),timer=setTimeout(()=>controller.abort(),18000);
  let r=await fetch(BUG_API,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({image:BUG_PHOTO,context:g?{river:prof(g)?.title||g.name,state:g.state,cfs:g.cfs,tempF:g.tempF,time:g.time}:null}),signal:controller.signal});
  clearTimeout(timer);let j=await r.json();if(!r.ok)throw Error(j.error||'Vision service unavailable');
  let group=BUG_TYPES[j.group]?j.group:'other',stage=(BUG_TYPES[group]?.stages||[]).includes(j.stage)?j.stage:(BUG_TYPES[group]?.stages?.[0]||'unknown');
  BUG_AI_RESULT={...j,group,stage};BUG_KIND=group;BUG_STAGE=stage;BUG_SIZE=j.size||BUG_SIZE;BUG_COLOR=j.color||BUG_TYPES[group]?.colors?.[0]||'natural';
  let conf=Number(j.confidence)||0;BUG_RESULT=conf>=.55&&group!=='other'?recommendBug():null;BUG_NOTE=conf>=.75?'Automatic ID complete. You can correct it below if needed.':conf>=.55?'Probable ID — check the photo and confirm if anything looks off.':'Low-confidence photo — use the correction choices below.';
 }catch(e){BUG_AI_RESULT=null;BUG_NOTE='Automatic Bug ID is temporarily unavailable. Use the correction choices below, or retry when connected.'}
 BUG_ANALYZING=false;draw();
}
function bugIdentifyView(){
 return`${bugContext()}${bugPhotoPanel()}${BUG_NOTE?`<div class="bugNote">${E(BUG_NOTE)}</div>`:''}${BUG_PHOTO?`${BUG_ANALYZING?`<div class="visionScanning glass"><span class="scanPulse"></span><div><b>Identifying automatically…</b><small>Group · life stage · size · color</small></div></div>`:''}${aiBugCard()}${BUG_AI_RESULT||!BUG_ANALYZING?`<section class="glass identifyAssist"><div class="sectionHead"><div><span class="ey">${BUG_AI_RESULT?'VERIFY / CORRECT':'MANUAL BACKUP'}</span><h2>${BUG_AI_RESULT?'Does this look right?':'Automatic ID needs a hand'}</h2></div><span class="confidence moderate">${BUG_AI_RESULT?'Optional check':'Fallback'}</span></div><p class="muted big">${BUG_AI_RESULT?'RiverFlow already chose the match. Only change these if the photo result looks wrong.':'Use the photo as a close-up reference and tap the closest insect group.'}</p>${bugTypeCards()}${stageChips()}${BUG_KIND&&BUG_STAGE?`<button id="buildMatch" class="primary glow">${BUG_RESULT?'Update fly match':'Build fly match'}</button>`:''}${!BUG_ANALYZING?`<button id="analyzeBug" class="textBtn">Retry automatic ID</button>`:''}</section>`:''}${bugResultCard(BUG_RESULT)}`:''}`;
}

function seasonName(m=MONTH()){return m<=2?'Winter':m<=5?'Spring':m<=8?'Summer':m<=11?'Fall':'Winter'}
function dayPart(){let h=new Date().getHours();return h<10?'Morning':h<16?'Midday':h<20?'Evening':'Night'}
function hatchToPatterns(h){
 let name=String(h?.[0]||'').toLowerCase(),size=h?.[1]||'#16–20',out=[];
 const add=(pattern,why,rank)=>out.push({pattern,size,why,rank});
 if(name.includes('pmd')){add('PMD Split Case','Match PMD nymphs before the hatch',1);add("Barr's Emerger",'Strong PMD emerger when fish move up',2);add('Sparkle Dun','Use when PMD duns are clearly on top',3)}
 else if(name.includes('bwo')||name.includes('baetis')){add('RS2','Excellent BWO emerger / slim nymph profile',1);add("Barr's Emerger",'Good transition pattern during emergence',2);add('Parachute Adams','Dry-fly backup when fish are rising',3)}
 else if(name.includes('trico')){add('Rusty Spinner','Best fit for spinner falls',1);add('RS2','Tiny subsurface backup',2);add('Parachute Adams','Visible backup dry in small sizes',3)}
 else if(name.includes('callibaetis')){add('Pheasant Tail','Good Callibaetis nymph profile',1);add("Barr's Emerger",'Use as bugs move toward the surface',2);add('Sparkle Dun','Dry option when adults are present',3)}
 else if(name.includes('green drake')){add('Green Drake Nymph','Match large pre-hatch mayfly nymphs',1);add('Green Drake Parachute','Use when big duns are on the surface',2);add('Pheasant Tail','Smaller general mayfly backup',3)}
 else if(name.includes('mayfl')){add('Pheasant Tail','General mayfly nymph match',1);add('RS2','Small emerger / mayfly backup',2);add('Parachute Adams','General dry when fish are looking up',3)}
 else if(name.includes('caddis')){add('Caddis Pupa','Best first subsurface caddis match',1);add('X-Caddis','Excellent low-riding adult/emerger',2);add('Elk Hair Caddis','High-floating adult backup',3)}
 else if(name.includes('midge')){add('Zebra Midge','Reliable midge larva/pupa pattern',1);add('RS2','Excellent tiny emerger',2);add("Griffith's Gnat",'Use when adults cluster on top',3)}
 else if(name.includes('stone')||name.includes('salmon')||name.includes('golden')){add("Pat's Rubber Legs",'Start with the stonefly nymph near the bottom',1);add('Chubby Chernobyl','Buoyant adult / attractor option',2);add('Stimulator','Classic stonefly dry backup',3)}
 else if(name.includes('terrestrial')||name.includes('hopper')||name.includes('ant')||name.includes('beetle')){add('Parachute Ant','Strong small terrestrial match',1);add('Foam Beetle','Excellent bank-side terrestrial',2);add('Morrish Hopper','Use when hoppers are active',3)}
 else if(name.includes('sow')){add('Sowbug','Direct sowbug match',1);add('Pheasant Tail','Slim nymph backup',2)}
 else if(name.includes('scud')){add('Scud','Direct freshwater scud match',1);add('Sowbug','Close-profile backup',2)}
 else{add('Pheasant Tail','General aquatic nymph starting point',1);add('Woolly Bugger','Search pattern when no hatch is obvious',2)}
 return out;
}
function advisorPatterns(g){
 let h=HB(g),all=[],seen=new Set();
 h.b.forEach((bug,bi)=>hatchToPatterns(bug).forEach((r,ri)=>{let key=r.pattern+'|'+r.size;if(!seen.has(key)){seen.add(key);all.push({...r,rank:bi*3+ri+1,bug:bug[0]})}}));
 // Tailwater food-base insurance that remains useful even when no hatch is visible.
 let n=(g.name||'').toUpperCase();
 if(/PROVO|GREEN RIVER NEAR GREENDALE/.test(n)){
  [['Sowbug','#16–20','Reliable tailwater food-base option'],['Zebra Midge','#20–24','Small midge insurance pattern']].forEach((x,i)=>{let key=x[0]+'|'+x[1];if(!seen.has(key)){seen.add(key);all.push({pattern:x[0],size:x[1],why:x[2],rank:20+i,bug:'Food base'})}})
 }
 let t=g.tempF,hour=new Date().getHours(),surface=(t==null||t>=50)&&(hour>=7&&hour<=20);
 // In cold water, push nymph/subsurface patterns ahead of dries. In summer evenings, lift adult/emerger options.
 all.forEach(r=>{let tags=patternTags(r.pattern);if(t!=null&&t<50&&(tags.includes('nymph')||tags.includes('larva')||tags.includes('pupa')))r.rank-=5;if(t!=null&&t<50&&tags.includes('dry'))r.rank+=7;if(surface&&hour>=17&&(tags.includes('emerger')||tags.includes('adult')||tags.includes('dry')))r.rank-=2});
 return all.sort((a,b)=>a.rank-b.rank).slice(0,8);
}
function advisorRig(g,recs){
 let t=g.tempF,h=dayPart(),first=recs[0];
 if(t!=null&&t>=70)return'Water is at or above 70°F. RiverFlow would not prioritize catch-and-release trout fishing here right now; check agency heat guidance before fishing.';
 if(t!=null&&t>=67)return'Water is warming. Fish early, land trout quickly, and stop if temperatures continue climbing.';
 if(t!=null&&t<50)return`Start subsurface with ${first?.pattern||'a small nymph'} and get the fly into the feeding lane before changing patterns.`;
 if(h==='Morning')return`Start with ${first?.pattern||'the top seasonal match'}. Watch for visible adults; switch toward an emerger/dry as rises become consistent.`;
 if(h==='Evening')return'Give caddis/emergers and low-riding dries extra attention near dusk, but keep a subsurface option ready if rises are inconsistent.';
 return'Fish the top seasonal match first. If you see no surface activity, start subsurface; if fish begin rising, move to the matching emerger or dry.';
}
function flyAdvisorData(){
 let g=lastRiver();if(!g)return null;let h=HB(g),recs=advisorPatterns(g),r=report(g),rs=reportState(r),confidence=rs.age<=7?'High':rs.age<=30?'Moderate':g.tempF!=null?'Moderate':'Seasonal';
 let ranked=rankBoxFlies(recs,5);
 return{g,h,recs,ranked,confidence,season:seasonName(),part:dayPart(),rig:advisorRig(g,recs),reportState:rs};
}
function flyAdvisorView(){
 let a=flyAdvisorData();
 if(!a)return`<section class="advisorHero glass"><span class="pill aqua">FLY ADVISOR</span><h1>No photo needed.</h1><p>Choose a river first. RiverFlow will use the date, season and river conditions to suggest what to fish from your saved fly box.</p><button data-app="rivers" class="primary glow">Choose a river →</button></section>`;
 let {g,h,recs,ranked}=a,p=prof(g),hot=g.tempF!=null&&g.tempF>=67;
 let hatchRows=h.b.slice(0,4).map(x=>`<div class="advisorBug"><b>${E(x[0])}</b><span>${E(x[1])}</span><small>${E(x[2])}</small></div>`).join('');
 let picks=ranked.length?ranked.slice(0,3).map((f,i)=>`<div class="advisorPick rank${i+1}"><span class="advisorNum">${i+1}</span><div><b>${E(f.pattern)} ${E(f.size)}</b><small>${E(f.color)} · ${E(f.boxName)} · ${i===0?'RiverFlow auto-pick':'Backup'}</small></div><em>${i===0?'AUTO PICK':Math.max(55,Math.min(99,Math.round(f.score)))+'%'}</em></div>`).join(''):recs.slice(0,3).map((f,i)=>`<div class="advisorPick rank${i+1}"><span class="advisorNum">${i+1}</span><div><b>${E(f.pattern)} ${E(f.size)}</b><small>${E(f.why)}</small></div><em>${i===0?'AUTO PICK':'BACKUP'}</em></div>`).join('');
 return`<section class="advisorHero"><span class="pill aqua">NO PHOTO NEEDED</span><h1>What should I use?</h1><p>${E(p?.title||g.name)} · ${E(a.season)} · ${E(a.part)}${g.tempF!=null?` · ${Math.round(g.tempF)}°F water`:''}</p></section>
 <section class="advisorSummary glass"><div class="sectionHead"><div><span class="ey">SEASONAL FLY PLAN</span><h2>${E(a.confidence)} confidence</h2></div><span class="confidence ${a.confidence==='High'?'high':'moderate'}">${E(a.reportState.age<=30?a.reportState.label:'Season + live water')}</span></div><p>RiverFlow is using the current time of year and this river's likely food/hatch profile${a.reportState.age<=30?' plus the dated local report':''}. It is not pretending a hatch is happening unless you actually observe it.</p>${hot?'<div class="aiCaution">Warm-water caution is active. Fish welfare takes priority over the fly recommendation.</div>':''}</section>
 <section class="advisorCard glass"><span class="ey">LIKELY FOOD / HATCHES</span><div class="advisorBugs">${hatchRows}</div></section>
 <section class="advisorCard glass"><div class="sectionHead"><div><span class="ey">${ranked.length?'AUTO-PICKED FROM MY BOXES':'BEST PATTERNS'}</span><h2>${ranked.length?`Use ${E(ranked[0].pattern)} ${E(ranked[0].size)} first.`:'Start with this fly.'}</h2></div>${mappedCount()?`<span class="boxCount">${mappedCount()} flies · ${BOXES.length} boxes</span>`:''}</div><div class="autoPickBanner">${ranked.length?`<span>✦ RIVERFLOW PICKED</span><b>${E(ranked[0].pattern)} ${E(ranked[0].size)}</b><small>${E(ranked[0].boxName)} · ${E(ranked[0].color)}</small>`:`<span>✦ RIVERFLOW PICKED</span><b>${E(recs[0]?.pattern||'Best seasonal match')}</b><small>${E(recs[0]?.size||'Match local size')}</small>`}</div><div class="advisorPicks">${picks}</div><div class="rigCallout"><span>STARTING PRESENTATION</span><b>${E(a.rig)}</b></div><div class="noBite"><span>IF NOTHING EATS</span><b>Fix depth and size first. Then switch life stage—nymph → emerger → dry—before abandoning the most likely insect family.</b></div>${ranked[0]?.boxImage?`<button id="advisorFindBox" class="primary glow">◎ Show #1 in ${E(ranked[0].boxName)}</button>`:`<button data-bugview="flybox" class="primary ghost">${mappedCount()?'Add photos to my fly boxes →':'Set up My Fly Boxes →'}</button>`}</section>
 <section class="advisorExplain glass"><span class="ey">WHY THIS CHANGES THROUGH THE YEAR</span><p>Winter leans toward midges and subsurface food. Spring adds BWO/caddis/stonefly activity. Summer shifts toward PMDs, caddis and terrestrials. Fall brings BWO, caddis, midges and aggressive-food opportunities. River-specific profiles override the generic season when RiverFlow has better local information.</p></section>`;
}
function bugLibraryView(){
 return`<section class="bugLibraryHero"><span class="ey">WESTERN TROUT BUGS</span><h1>Bug Library</h1><p>Fast field reference for the insect groups that matter most to trout anglers.</p></section><div class="libraryGrid">${Object.entries(BUG_TYPES).filter(([k])=>k!=='other').map(([k,v])=>`<article class="libraryCard ${k}"><div class="libIcon"><span>${v.symbol}</span></div><div><b>${v.label}</b><p>${v.hint}</p><div class="libStages">${v.stages.map(s=>`<span>${s}</span>`).join('')}</div></div><button data-lib="${k}">Use this ID →</button></article>`).join('')}</div><section class="glass fieldTip"><span>FIELD TIP</span><b>Life stage usually matters as much as the insect name.</b><p>A mayfly nymph and a mayfly spinner can require completely different presentations even though they are the same insect group.</p></section>`;
}
function saveBox(){saveBoxes()}
function boxShelf(){
 let cards=BOXES.map(b=>`<button class="boxCard ${b.id===ACTIVE_BOX_ID?'on':''}" data-boxid="${E(b.id)}">${b.image?`<img src="${b.image}" alt="">`:`<span class="boxThumb">▦</span>`}<b>${E(b.name)}</b><small>${b.flies?.length||0} mapped</small></button>`).join('');
 return`<section class="boxShelf glass"><div class="sectionHead"><div><span class="ey">SAVED ON THIS PHONE</span><h2>${BOXES.length} fly ${BOXES.length===1?'box':'boxes'}</h2></div><button id="addBox" class="miniBtn">＋ Add box</button></div><div class="boxCards">${cards}</div><div class="boxLocalNote"><span>● LOCAL</span> Photos and fly locations stay in RiverFlow on this phone. They are not uploaded for Fly Advisor matching.</div>${BOX_STORAGE_NOTE?`<div class="aiCaution">${E(BOX_STORAGE_NOTE)}</div>`:''}</section>`;
}
function boxPhoto(){
 if(BUG_CAMERA==='box')return`<section class="cameraStage"><video id="bugVideo" autoplay playsinline muted></video><div class="cameraShade"></div><div class="boxGuide"><span>Fit the whole open box inside the frame</span></div><div class="cameraTop"><button id="cameraClose">×</button><span>${E(BOX.name||'FLY BOX')} SCAN</span><i>LOCAL</i></div><div class="cameraBottom"><button id="cameraGallery">▣</button><button id="cameraShutter" class="shutter"><i></i></button><button disabled>✦</button></div><input id="boxFile" type="file" accept="image/*" capture="environment" hidden></section>`;
 if(!BOX.image)return`${boxShelf()}<section class="boxIntro glass"><div class="boxNameRow"><label><span>BOX NAME</span><input id="boxName" value="${E(BOX.name)}" maxlength="32"></label>${BOXES.length>1?'<button id="deleteBox" class="dangerMini">Delete</button>':''}</div><div class="boxSketch"><i></i><i></i><i></i><i></i><i></i><i></i></div><span class="pill">ACTIVE FLY BOX</span><h2>Save ${E(BOX.name)}.</h2><p>Take one straight-on photo. RiverFlow stores it locally, so you can keep all of your boxes on the phone and search across them when it recommends a fly.</p><button id="scanBox" class="primary glow">◎ Photograph this box</button><button id="uploadBox" class="textBtn">Choose box photo</button><input id="boxFile" type="file" accept="image/*" capture="environment" hidden></section>`;
 let markers=BOX.flies.map((f,i)=>`<button class="boxMarker" style="left:${f.x}%;top:${f.y}%" data-boxmarker="${i}"><span>${i+1}</span></button>`).join('');
 return`${boxShelf()}<section class="boxMap glass"><div class="sectionHead"><div><span class="ey">ACTIVE BOX</span><h2>${E(BOX.name)} · ${BOX.flies.length} mapped</h2></div><div class="boxTopBtns"><button id="rescanBox" class="miniBtn">New photo</button>${BOXES.length>1?'<button id="deleteBox" class="dangerMini">Delete</button>':''}</div></div><div class="boxNameRow compact"><label><span>BOX NAME</span><input id="boxName" value="${E(BOX.name)}" maxlength="32"></label></div><p class="muted big">Box setup only: choose the pattern/size once, then tap its location. During fishing, RiverFlow picks the fly automatically across every saved box.</p><div id="boxImage" class="boxImage"><img src="${BOX.image}" alt="Fly box">${markers}</div><div class="boxForm"><label><span>Pattern to map</span><select id="boxPattern">${FLY_CATALOG.map(f=>`<option ${BOX_PICK.pattern===f.name?'selected':''}>${E(f.name)}</option>`).join('')}</select></label><label><span>Size</span><select id="boxSize">${['#4','#6','#8','#10','#12','#14','#16','#18','#20','#22','#24','#26'].map(s=>`<option ${BOX_PICK.size===s?'selected':''}>${s}</option>`).join('')}</select></label><label><span>Color</span><select id="boxColor">${['natural','black','olive','tan','cream','brown','red','orange','purple'].map(s=>`<option ${BOX_PICK.color===s?'selected':''}>${s}</option>`).join('')}</select></label></div><div class="tapHint">＋ Tap that fly's exact position in the photo</div>${BOX.flies.length?`<div class="mappedList">${BOX.flies.slice().reverse().slice(0,12).map((f,ri)=>{let i=BOX.flies.length-1-ri;return`<div><span>${i+1}</span><b>${E(f.pattern)} ${E(f.size)}</b><small>${E(f.color)}</small><button data-delbox="${i}">×</button></div>`}).join('')}</div>`:''}</section>`;
}
function scoreBoxFly(f,recs){
 let score=0;
 for(let r of recs){
  let rank=Number(r.rank)||1,ft=patternTags(f.pattern),rt=patternTags(r.pattern),overlap=ft.filter(x=>rt.includes(x)).length,sizeGap=Math.abs(bugSizeNumber(f.size)-bugSizeNumber(r.size));
  let candidate=overlap*18-sizeGap*2;
  if(f.pattern===r.pattern)candidate=Math.max(candidate,108-rank*4-sizeGap*2);
  if(r.color&&r.color!=='best match'&&f.color===r.color)candidate+=5;
  score=Math.max(score,candidate);
 }
 return score;
}
function boxMatchView(){
 let rec=BUG_RESULT||recommendBug(),ranked=rankBoxFlies(rec.flies,5);
 if(!mappedCount())return`<section class="boxMatchHero glass"><span class="pill aqua">FLYBOX MATCH</span><h2>Map a fly box first</h2><p>Save a box photo and tag its flies once. After that RiverFlow will choose the best fly automatically.</p><button data-bugview="flybox" class="primary">Set up My Fly Boxes</button></section>`;
 if(!ranked.length)return`<section class="boxMatchHero glass"><span class="pill aqua">FLYBOX MATCH</span><h2>No close match in your saved boxes</h2><p>RiverFlow recommends <b>${E(rec.flies?.[0]?.pattern||'the top hatch match')}</b>, but none of your mapped flies are close enough for a confident auto-pick.</p><button data-bugview="flybox" class="primary ghost">Review my fly boxes</button></section>`;
 let winner=ranked[0],wb=BOXES.find(b=>b.id===winner.boxId),rankMap=new Map(ranked.slice(0,3).map((f,i)=>[`${f.boxId}:${f.i}`,i+1]));
 let marks=(wb?.flies||[]).map((f,i)=>rankMap.has(`${winner.boxId}:${i}`)?`<span class="matchMarker rank${rankMap.get(`${winner.boxId}:${i}`)}" style="left:${f.x}%;top:${f.y}%">${rankMap.get(`${winner.boxId}:${i}`)}</span>`:'').join('');
 let img=wb?.image||winner.boxImage||'';
 return`<section class="matchHero"><span class="pill aqua">AUTO FLY PICK</span><h1>Use this fly.</h1><p>${E(rec.type||'hatch')} · ${E(rec.stage||'stage')} · ${E(rec.size||BUG_SIZE)} · ${E(rec.color||BUG_COLOR)}</p></section><section class="autoWinner glass"><span>✦ RIVERFLOW #1 PICK</span><h2>${E(winner.pattern)} ${E(winner.size)}</h2><p>${E(winner.color)} · <b>${E(winner.boxName)}</b></p><div class="winnerScore">${Math.max(55,Math.min(99,Math.round(winner.score)))}% match</div></section><section class="glass boxMatchCard">${img?`<div class="boxImage match"><img src="${img}" alt="${E(winner.boxName)}">${marks}</div>`:'<div class="empty">The fly is mapped, but this box photo is unavailable.</div>'}<div class="matchList">${ranked.slice(0,3).map((f,i)=>`<div class="matchRow"><span class="num n${i+1}">${i+1}</span><div><b>${E(f.pattern)} ${E(f.size)}</b><small>${E(f.boxName)} · ${E(f.color)} · ${i===0?'use first':'backup'}</small></div><em>${i===0?'PICKED':Math.max(55,Math.min(99,Math.round(f.score)))+'%'}</em></div>`).join('')}</div>${img?`<button id="liveBox" class="primary glow">◎ Point camera at ${E(winner.boxName)}</button>`:''}</section>`;
}
function liveBoxView(){
 let rec=BUG_RESULT||recommendBug(),ranked=rankBoxFlies(rec.flies,5),winner=ranked[0];if(!winner)return boxMatchView();
 let b=BOXES.find(x=>x.id===winner.boxId),rankMap=new Map(ranked.slice(0,3).map((f,i)=>[`${f.boxId}:${f.i}`,i+1])),img=b?.image||winner.boxImage||'';
 return`<section class="cameraStage liveBox"><video id="bugVideo" autoplay playsinline muted></video>${img?`<img class="ghostBox" src="${img}" alt="">`:''}${(b?.flies||[]).map((f,i)=>rankMap.has(`${b.id}:${i}`)?`<span class="liveMarker rank${rankMap.get(`${b.id}:${i}`)}" style="left:${f.x}%;top:${f.y}%">${rankMap.get(`${b.id}:${i}`)}</span>`:'').join('')}<div class="cameraTop"><button id="cameraClose">×</button><span>${E(b?.name||winner.boxName)}</span><i>AUTO PICK</i></div><div class="liveHint">Align the box with the faint saved image.<br><b>#1 is RiverFlow's automatic fly choice.</b></div></section>`;
}
function bugFlyboxView(){return`${boxPhoto()}${mappedCount()?`<section class="glass flyboxHow"><span class="ey">MULTI-BOX MATCHING</span><h2>One inventory. Every box.</h2><p>RiverFlow searches every locally saved box at once. Fly Advisor or Bug ID chooses the #1 fly automatically, names the box, and highlights its exact saved location. #2 and #3 are backups only.</p></section>`:''}`}
function bugLab(){
 let body=BUG_VIEW==='advisor'?flyAdvisorView():BUG_VIEW==='identify'?bugIdentifyView():BUG_VIEW==='library'?bugLibraryView():BUG_VIEW==='match'?boxMatchView():BUG_VIEW==='live'?liveBoxView():bugFlyboxView();
 return`<header class="top bugTop"><div><div class="brand"><b>≈</b> RiverFlow</div><div class="sub">ON-WATER ENTOMOLOGY</div></div><div class="bugStatus"><span></span>FIELD MODE</div></header>${mainNav()}<section class="bugTabs"><button data-bugview="advisor" class="${BUG_VIEW==='advisor'?'on':''}">✦ Fly Advisor</button><button data-bugview="identify" class="${BUG_VIEW==='identify'?'on':''}">◎ Bug ID</button><button data-bugview="library" class="${BUG_VIEW==='library'?'on':''}">⌁ Library</button><button data-bugview="flybox" class="${BUG_VIEW==='flybox'?'on':''}">▦ My Fly Box</button></section><main class="bugMain">${body}</main><footer>RiverFlow Fly Advisor uses seasonal biology and current river context as decision support; Bug ID adds direct on-water observation. Neither is a guarantee of an active hatch.</footer>`;
}
function stopCamera(){if(BUG_STREAM){try{BUG_STREAM.getTracks().forEach(t=>t.stop())}catch{}BUG_STREAM=null}}
async function openCamera(){
 let v=$('#bugVideo');if(!v)return;
 try{
  if(window.RiverFlowNative?.requestCamera)window.RiverFlowNative.requestCamera();
  BUG_STREAM=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}},audio:false});
  v.srcObject=BUG_STREAM;await v.play();
 }catch(e){BUG_NOTE='Camera unavailable. Use Choose Photo instead.';stopCamera();BUG_CAMERA='';if(BUG_VIEW==='live')BUG_VIEW='match';draw()}
}
function startBugCamera(kind){stopCamera();BUG_NOTE='';BUG_CAMERA=kind;BUG_VIEW=kind==='bug'?'identify':'flybox';draw();setTimeout(openCamera,80)}
function setActiveBoxPhoto(data){BOX.image=data;BOX.flies=[];saveBox();putBoxImage(BOX.id,data)}
function captureFrame(){
 let v=$('#bugVideo');if(!v||!v.videoWidth)return;
 let max=1280,scale=Math.min(1,max/v.videoWidth),c=document.createElement('canvas');c.width=Math.round(v.videoWidth*scale);c.height=Math.round(v.videoHeight*scale);c.getContext('2d').drawImage(v,0,0,c.width,c.height);
 let data=c.toDataURL('image/jpeg',.82),kind=BUG_CAMERA;stopCamera();BUG_CAMERA='';
 if(kind==='bug'){BUG_PHOTO=data;BUG_KIND='';BUG_STAGE='';BUG_RESULT=null;BUG_AI_RESULT=null;BUG_VIEW='identify'}else{setActiveBoxPhoto(data);BUG_VIEW='flybox'}
 draw();if(kind==='bug')queueAutoBugAnalysis();
}
function readImageFile(file,kind){
 if(!file)return;let r=new FileReader();r.onload=()=>{let img=new Image();img.onload=()=>{let max=1280,scale=Math.min(1,max/img.width),c=document.createElement('canvas');c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext('2d').drawImage(img,0,0,c.width,c.height);let d=c.toDataURL('image/jpeg',.82);if(kind==='bug'){BUG_PHOTO=d;BUG_KIND='';BUG_STAGE='';BUG_RESULT=null;BUG_AI_RESULT=null;BUG_VIEW='identify'}else{setActiveBoxPhoto(d);BUG_VIEW='flybox'}draw();if(kind==='bug')queueAutoBugAnalysis()};img.src=r.result};r.readAsDataURL(file)
}
function addBoxPoint(ev){
 let el=$('#boxImage');if(!el)return;let r=el.getBoundingClientRect(),x=Math.max(0,Math.min(100,(ev.clientX-r.left)/r.width*100)),y=Math.max(0,Math.min(100,(ev.clientY-r.top)/r.height*100));
 BOX.flies.push({pattern:BOX_PICK.pattern,size:BOX_PICK.size,color:BOX_PICK.color,x:+x.toFixed(2),y:+y.toFixed(2)});saveBox();draw();
}
function bugWire(){
 document.querySelectorAll('[data-bugview]').forEach(b=>b.onclick=()=>{stopCamera();BUG_CAMERA='';BUG_VIEW=b.dataset.bugview;draw();if(BUG_VIEW==='live')setTimeout(openCamera,80)});
 $('#takeBug')?.addEventListener('click',()=>startBugCamera('bug'));$('#uploadBug')?.addEventListener('click',()=>$('#bugFile')?.click());
 $('#scanBox')?.addEventListener('click',()=>startBugCamera('box'));$('#uploadBox')?.addEventListener('click',()=>$('#boxFile')?.click());$('#rescanBox')?.addEventListener('click',()=>startBugCamera('box'));
 $('#cameraClose')?.addEventListener('click',()=>{stopCamera();BUG_CAMERA='';if(BUG_VIEW==='live')BUG_VIEW='match';draw()});
 $('#cameraShutter')?.addEventListener('click',captureFrame);$('#cameraGallery')?.addEventListener('click',()=>$(BUG_CAMERA==='bug'?'#bugFile':'#boxFile')?.click());
 $('#bugFile')?.addEventListener('change',e=>readImageFile(e.target.files?.[0],'bug'));$('#boxFile')?.addEventListener('change',e=>readImageFile(e.target.files?.[0],'box'));
 $('#analyzeBug')?.addEventListener('click',analyzeBugPhoto);$('#retakeBug')?.addEventListener('click',()=>startBugCamera('bug'));$('#clearBug')?.addEventListener('click',()=>{BUG_PHOTO='';BUG_KIND='';BUG_STAGE='';BUG_RESULT=null;BUG_AI_RESULT=null;draw()});
 document.querySelectorAll('[data-bugtype]').forEach(b=>b.onclick=()=>{BUG_KIND=b.dataset.bugtype;BUG_STAGE=BUG_TYPES[BUG_KIND]?.stages?.[0]||'';BUG_COLOR=BUG_TYPES[BUG_KIND]?.colors?.[0]||'natural';BUG_RESULT=null;draw()});
 document.querySelectorAll('[data-stage]').forEach(b=>b.onclick=()=>{BUG_STAGE=b.dataset.stage;BUG_RESULT=null;draw()});
 $('#bugSize')?.addEventListener('change',e=>{BUG_SIZE=e.target.value;BUG_RESULT=null;draw()});$('#bugColor')?.addEventListener('change',e=>{BUG_COLOR=e.target.value;BUG_RESULT=null;draw()});
 $('#buildMatch')?.addEventListener('click',()=>{BUG_RESULT=recommendBug();draw()});$('#matchBox')?.addEventListener('click',()=>{BUG_VIEW='match';draw()});
 document.querySelectorAll('[data-lib]').forEach(b=>b.onclick=()=>{BUG_KIND=b.dataset.lib;BUG_STAGE=BUG_TYPES[BUG_KIND].stages[0];BUG_COLOR=BUG_TYPES[BUG_KIND].colors[0];BUG_RESULT=null;BUG_VIEW='identify';draw()});
 document.querySelectorAll('[data-boxid]').forEach(b=>b.onclick=()=>{activateBox(b.dataset.boxid);draw()});$('#addBox')?.addEventListener('click',newBox);$('#deleteBox')?.addEventListener('click',removeActiveBox);
 $('#boxName')?.addEventListener('change',e=>{BOX.name=(e.target.value||'Fly Box').trim().slice(0,32)||'Fly Box';saveBox();draw()});
 $('#boxPattern')?.addEventListener('change',e=>{BOX_PICK.pattern=e.target.value});$('#boxSize')?.addEventListener('change',e=>{BOX_PICK.size=e.target.value});$('#boxColor')?.addEventListener('change',e=>{BOX_PICK.color=e.target.value});
 $('#boxImage')?.addEventListener('click',addBoxPoint);document.querySelectorAll('[data-delbox]').forEach(b=>b.onclick=e=>{e.stopPropagation();BOX.flies.splice(+b.dataset.delbox,1);saveBox();draw()});
 $('#liveBox')?.addEventListener('click',()=>{BUG_VIEW='live';draw();setTimeout(openCamera,80)});
 $('#advisorFindBox')?.addEventListener('click',()=>{let a=flyAdvisorData();if(a){BUG_RESULT={type:'seasonal',stage:a.season.toLowerCase(),size:a.recs[0]?.size||'#16–20',color:'best match',flies:a.recs,rig:a.rig,river:prof(a.g)?.title||a.g.name};BUG_VIEW='match';draw()}});
}
function reportCard(g){let r=report(g),c=CONF(g);if(!r)return`<section class="card"><span class="pill">Fishing intel</span><h2>Current report unavailable</h2><p class="muted big">Live flow, temperature and weather still feed the score, but RiverFlow does not have a recent trusted local report for this reach.</p>${reportBadge(g)}</section>`;let rs=reportState(r);return`<section class="card intelCard"><div class="sectionHead"><div><span class="pill">Fishing report</span><h2>${E(r.source)}</h2></div><span class="fresh ${rs.cls}">${E(rs.label)}</span></div><p class="bodycopy">${E(r.summary)}</p>${reportBadge(g)}<a class="evidence" target="_blank" href="${E(r.url)}">Read source report ↗</a>${rs.age>14?'<div class="staleInline">This report is aging. RiverFlow gives it less weight than live conditions.</div>':''}</section>`}
function trophyCard(g){let p=prof(g);if(!p)return`<section class="card"><span class="pill">🏆 Big-fish intel</span><h2>Not rated</h2><p class="muted big">No reach-specific fish-size evidence has been attached yet.</p></section>`;return`<section class="card trophyCard"><div class="trophyHead"><div><span class="pill goldpill">${p.trophyVerified?'🏆 Verified big-fish river':'Big-fish potential'}</span><h2>${p.trophy>=5?'Very high':p.trophy>=4?'High':'Moderate'}</h2></div><div class="trophyStars">${'★'.repeat(Math.round(p.trophy))}${'☆'.repeat(5-Math.round(p.trophy))}<small>${p.trophy}/5</small></div></div><div class="trophyGrid"><div><span>Typical class</span><b>${E(p.typical)}</b></div><div><span>Large-fish evidence</span><b>${E(p.plus)}</b></div><div><span>Best trophy season</span><b>${E(p.trophySeason)}</b></div><div><span>Evidence confidence</span><b>${E(p.confidence)}</b></div></div><p class="bodycopy">${E(p.why)}</p><div class="section">Approach for larger fish</div><p class="bodycopy">${E(p.tactics)}</p><div class="species">${E(p.species)}</div>${p.agencyUrl?`<a class="evidence" target="_blank" href="${E(p.agencyUrl)}">Agency evidence ↗</a>`:''}</section>`}
function scoreCard(g){let s=SCORE(g),p=prof(g);return`<section class="card"><div class="scoreHero"><div><span class="pill">RiverScore · ${planLabel()}</span><h2>${s.n}/100 · ${s.n>=84?'Excellent candidate':s.n>=70?'Strong candidate':s.n>=55?'Worth a look':'Conditions reduce the score'}</h2></div><div class="score bigScore ${scoreClass(s.n)}"><b>${s.n}</b><small>/100</small></div></div><div class="section">Why RiverFlow thinks this</div><div class="whyList">${why(g).map(x=>`<div>${E(x)}</div>`).join('')}</div>${p?`<div class="section">Best for</div><div class="bestTags">${p.best.map(x=>`<span>${E(x)}</span>`).join('')}</div>`:''}</section>`}
function HB(g){
 let n=g.name.toUpperCase(),m=MONTH(),food=['Midges','Mayfly nymphs','Caddis larvae','Stonefly nymphs','Terrestrials'],b;
 if(m<=2)b=[['Midges','#20–26','Zebra Midge / RS2'],['BWO / small mayflies','#18–24','RS2 / nymph'],['Mayfly nymphs','#16–22','Pheasant Tail']];
 else if(m<=4)b=[['BWO','#18–22','RS2 / emerger'],['Midges','#20–24','Zebra Midge'],['Stonefly nymphs','#8–14',"Pat's Rubber Legs"],['Caddis','#16–20','Larva / pupa']];
 else if(m===5)b=[['BWO / mayflies','#16–22','Nymph / emerger'],['Caddis','#14–18','Pupa / X-Caddis'],['Stoneflies','#8–14',"Pat's Rubber Legs / dry"]];
 else if(m===6)b=[['PMD','#16–20','PMD Split Case / emerger'],['Caddis','#14–18','Pupa / X-Caddis'],['Stoneflies','#8–14',"Pat's Rubber Legs / dry"]];
 else if(m===7)b=[['PMD','#16–20','Emerger / dry'],['Caddis','#14–18','X-Caddis / pupa'],['Terrestrials','#10–16','Ant / hopper'],['Stoneflies','#8–14','Stimulator / Chubby']];
 else if(m===8)b=[['PMD','#16–20','PMD emerger'],['Caddis','#14–18','X-Caddis'],['Terrestrials','#10–16','Ant / hopper']];
 else if(m===9)b=[['BWO','#18–22','RS2 / emerger'],['Caddis','#14–18','Pupa / dry'],['Terrestrials','#10–16','Ant / hopper'],['Midges','#20–24','Zebra Midge']];
 else if(m===10)b=[['BWO','#18–22','RS2 / emerger'],['Midges','#20–24','Zebra Midge'],['Caddis','#16–20','Pupa / dry']];
 else b=[['Midges','#20–26','Zebra Midge / RS2'],['BWO / small mayflies','#18–24','RS2 / nymph'],['Mayfly nymphs','#16–22','Pheasant Tail']];
 let r=report(g);
 if(n.includes('PROVO')){
  food=['Sowbugs','Midges','PMD nymphs','Caddis larvae','BWO nymphs','Terrestrials'];
  if(m<=2)b=[['Midges','#20–26','Zebra / RS2'],['Sowbugs','#16–20','Sowbug'],['BWO nymphs','#18–22','RS2 / Pheasant Tail']];
  else if(m<=4)b=[['BWO','#18–22','RS2 / emerger'],['Midges','#20–26','Zebra / RS2'],['Sowbugs','#16–20','Sowbug']];
  else if(m===5)b=[['BWO / PMD nymphs','#16–22','Pheasant Tail / emerger'],['Caddis','#16–20','Pupa / X-Caddis'],['Sowbugs','#16–20','Sowbug']];
  else if(m===6)b=[['PMD','#16–20','PMD Split Case / emerger'],['Green Drake','#10–14','Green Drake nymph / dry'],['Caddis','#16–20','X-Caddis / pupa'],['Midges','#20–24','Zebra / RS2']];
  else if(m===7)b=[['PMD','#16–20','Emerger / dry'],['Caddis','#16–20','X-Caddis / pupa'],['Green Drake','#10–14','Green Drake dry (when present)'],['Terrestrials','#12–18','Ant']];
  else if(m===8)b=[['PMD','#16–22','Split Case / emerger'],['Caddis','#16–20','X-Caddis / pupa'],['Midges','#20–26','Zebra / RS2'],['Terrestrials','#12–18','Ant']];
  else if(m<=10)b=[['BWO','#18–22','RS2 / emerger'],['Caddis','#16–20','Pupa / dry'],['Midges','#20–26','Zebra / RS2'],['Sowbugs','#16–20','Sowbug']];
  else b=[['Midges','#20–26','Zebra / RS2'],['Sowbugs','#16–20','Sowbug'],['BWO nymphs','#18–22','RS2 / Pheasant Tail']];
 }
 if(n.includes('GREEN RIVER NEAR GREENDALE')){
  food=['Scuds','Midges','BWO nymphs','Caddis larvae','PMD nymphs','Terrestrials'];
  if(m<=2||m>=11)b=[['Midges','#20–24','Zebra Midge / RS2'],['Scuds','#14–18','Scud'],['BWO nymphs','#18–22','RS2']];
  else if(m<=4)b=[['BWO','#18–22','RS2 / emerger'],['Midges','#20–24','Zebra Midge'],['Scuds','#14–18','Scud']];
  else if(m<=6)b=[['PMD / mayflies','#16–20','Emerger / dry'],['Caddis','#14–18','Pupa / X-Caddis'],['Scuds','#14–18','Scud']];
  else if(m<=8)b=[['PMD','#16–20','Emerger / dry'],['Caddis','#14–18','X-Caddis / pupa'],['Terrestrials','#10–16','Ant / hopper'],['Scuds','#14–18','Scud']];
  else b=[['BWO','#18–22','RS2 / emerger'],['Caddis','#14–18','Pupa / dry'],['Midges','#20–24','Zebra Midge'],['Scuds','#14–18','Scud']];
 }
 if(n.includes('HENRYS FORK')){
  if(m===5||m===6)b=[['Stoneflies / salmonflies','#6–10',"Pat's Rubber Legs / Chubby"],['PMD','#16–20','Emerger / dry'],['Caddis','#14–18','Pupa / X-Caddis']];
  else if(m===7)b=[['PMD','#16–20','Emerger / dry'],['Caddis','#14–18','X-Caddis / pupa'],['Green Drake','#10–14','Green Drake dry'],['Terrestrials','#10–16','Ant / hopper']];
  else if(m===8)b=[['PMD / small mayflies','#16–22','Emerger / dry'],['Caddis','#14–18','X-Caddis'],['Terrestrials','#10–16','Ant / hopper'],['Trico / tiny mayfly','#20–24','Spinner']];
  else if(m>=9&&m<=10)b=[['BWO / small mayflies','#18–22','RS2 / dry'],['Caddis','#16–20','Pupa / dry'],['Terrestrials','#10–16','Ant / beetle']];
 }
 if(n.includes('SILVER CREEK')){
  if(m===6||m===7)b=[['PMD','#14–20','Emerger / spinner'],['Callibaetis','#14–16','Nymph / emerger'],['Trico / tiny mayfly','#20–24','Spinner'],['Caddis','#16–20','Pupa / dry']];
  else if(m===8)b=[['PMD','#14–20','Emerger / spinner'],['Callibaetis','#14–16','Emerger'],['Trico / tiny mayfly','#20–24','Spinner'],['Terrestrials','#12–16','Ant / hopper']];
  else if(m===9)b=[['Trico / tiny mayfly','#20–24','Spinner'],['BWO','#18–22','Emerger / dry'],['Callibaetis','#14–18','Nymph / emerger'],['Terrestrials','#12–16','Ant / beetle']];
 }
 if(n.includes('ST JOE')&&m>=7&&m<=9)b=[['Caddis','#14–18','Caddis dry'],['Terrestrials','#10–16','Hopper / ant / beetle'],['Small mayflies','#18–22','Small parachute']];
 // A recent report may reorder likely bugs, but never fabricates a hatch that is absent from the seasonal river profile.
 if(r&&reportState(r).age<=30){let text=String(r.summary||'').toLowerCase(),hit=x=>{let n=String(x[0]).toLowerCase(),score=0;if(/pmd/.test(n)&&text.includes('pmd'))score+=4;if(/caddis/.test(n)&&text.includes('caddis'))score+=4;if(/midge/.test(n)&&text.includes('midge'))score+=4;if(/bwo|baetis/.test(n)&&/bwo|baetis/.test(text))score+=4;if(/terrestrial|ant|hopper|beetle/.test(n)&&/ant|hopper|terrestrial|beetle/.test(text))score+=4;if(/stone|salmon/.test(n)&&/stone|salmonfly/.test(text))score+=4;if(/trico/.test(n)&&text.includes('trico'))score+=4;return score};b=b.map((x,i)=>({x,i,h:hit(x)})).sort((a,z)=>z.h-a.h||a.i-z.i).map(o=>o.x)}
 return{food,b,source:r}
}
function bugsCard(g){let h=HB(g),r=h.source,rs=reportState(r);return`<section class="card"><span class="pill">River bugs</span><h2>${r&&rs.age<=30?'Report-informed + seasonal':'Seasonal estimate'}</h2><p class="muted big">Hatch suggestions are never treated as a live sensor. ${r&&rs.age<=30?`A ${rs.age}-day-old local report is helping the list below.`:'No fresh enough trusted report is available, so this leans on seasonal biology.'}</p><div class="section gap">Likely bugs</div>${h.b.map(x=>`<div class="bug"><div><b>${x[0]}</b><p>Try: ${x[2]}</p></div><div class="size">${x[1]}</div></div>`).join('')}<div class="section gap">Food base</div>${h.food.map(x=>`<span class="food">${x}</span>`).join('')}<div class="riverFlyActions"><button id="flyAdvisorFromRiver" class="primary glow">✦ What should I use now?</button><button id="bugFromRiver" class="primary bugLaunch">◎ Identify a bug at this river</button></div></section>`}
function detail(){let g=S,p=prof(g),d=distText(g),hn=heatNote(g);return`<section class="detail"><button id="back" class="back">← Back to rivers</button><div class="head"><div><div class="badges"><span class="pill">${g.state} · USGS</span>${badges(g)}</div><h1>${E(p?.title||g.name)}</h1><p>${E(g.name)} · Gauge ${g.id} · ${AGE(g.time)}${d?` · 📍 ${d} from you`:''}</p></div><button id="star" class="icon ${F.includes(g.id)?'on':''}">★</button></div><div class="metrics"><div class="metric"><span>Current discharge</span><b>${N(g.cfs)} <small>CFS</small></b><small>USGS provisional</small></div><div class="metric"><span>Water temperature</span><b>${g.tempF==null?'—':Math.round(g.tempF)+'°'}<small>${g.tempF==null?'':'F'}</small></b><small>${g.tempF==null?'Not reported':`${g.tempC.toFixed(1)}°C`}</small></div></div>${g.tempF!=null&&g.tempF>=67?`<div class="heat">⚠ ${g.tempF>=70?'Warm-water danger':'Water is warming'}: RiverScore strongly reduces this fishery for catch-and-release trout as temperature rises.</div>`:''}${hn?`<div class="advisory"><b>⚠ Agency heat advisory</b><span>${E(hn.text)}</span><a target="_blank" href="${hn.url}">Check current status ↗</a></div>`:''}${p?.blue?`<div class="note"><b>${E(p.agency)}</b> · Verified Blue Ribbon quality designation. Blue Ribbon does not automatically mean trophy-size fish.</div>`:''}${scoreCard(g)}${reportCard(g)}${trophyCard(g)}<section id="weather" class="card"><span class="pill">5-day forecast</span><h2>Weather at this gauge</h2><p class="muted big">Loading temperature, precipitation and wind…</p></section>${bugsCard(g)}<section class="card"><div class="ranges"><span class="section">Flow history</span><div>${[1,3,7,14,30].map(x=>`<button data-d="${x}" class="${D===x?'on':''}">${x}D</button>`).join('')}</div></div><div id="chart" class="muted big">Loading history…</div></section><div class="actionRow">${g.lat&&g.lng?`<a class="source secondary" target="_blank" href="https://www.google.com/maps/dir/?api=1&destination=${g.lat},${g.lng}">Directions ↗</a>`:''}<a class="source" target="_blank" href="https://waterdata.usgs.gov/monitoring-location/USGS-${g.id}/">Official USGS ↗</a></div><footer>Intel confidence reflects source quality and freshness. Always verify regulations, access and current agency advisories.</footer></section>`}

function draw(){if(M){try{M.remove()}catch{}M=null}if(APP_TAB==='bugs'){S=null;app.innerHTML=bugLab();wire();return}app.innerHTML=S?detail():home();wire();if(S){historyLoad();weather()}else{if(V==='map')setTimeout(map,0);setTimeout(prefetch,80)}}
function results(){let old=$('#rows');if(!old)return;let d=document.createElement('div');d.innerHTML=rows();old.replaceWith(d.firstElementChild);rowWire()}
function toggle(i){F=F.includes(i)?F.filter(x=>x!==i):[...F,i];localStorage.setItem('riverflow-favorites',JSON.stringify(F));draw()}
function rowWire(){document.querySelectorAll('[data-o]').forEach(b=>b.onclick=()=>openGauge(b.dataset.o));document.querySelectorAll('[data-f]').forEach(b=>b.onclick=e=>{e.stopPropagation();toggle(b.dataset.f)})}
function requestLocation(){LOCATING=true;LOCERR='';draw();if(window.RiverFlowNative?.requestLocation){window.RiverFlowNative.requestLocation();return}if(navigator.geolocation)navigator.geolocation.getCurrentPosition(p=>window.RiverFlowLocation(p.coords.latitude,p.coords.longitude,p.coords.accuracy),e=>window.RiverFlowLocationError(e.message),{enableHighAccuracy:true,timeout:10000});else window.RiverFlowLocationError('Location is not available on this device.')}
window.RiverFlowLocation=(lat,lng,acc)=>{LOC={lat:+lat,lng:+lng,acc:+acc||0};LOCATING=false;LOCERR='';MODE='nearby';draw()};
window.RiverFlowLocationError=msg=>{LOCATING=false;LOCERR=msg||'Location unavailable';MODE='nearby';draw()};
function wire(){document.querySelectorAll('[data-app]').forEach(b=>b.onclick=()=>{stopCamera();APP_TAB=b.dataset.app;localStorage.setItem('riverflow-main-tab',APP_TAB);S=null;draw();scrollTo(0,0)});if(APP_TAB==='bugs'){bugWire();return}rowWire();$('#search')?.addEventListener('input',e=>{Q=e.target.value;results()});document.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{ST=b.dataset.s;draw()});document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{MODE=b.dataset.mode;if(MODE==='nearby'&&!LOC)requestLocation();else draw()});document.querySelectorAll('[data-plan]').forEach(b=>b.onclick=()=>{PLAN=b.dataset.plan;draw()});document.querySelectorAll('[data-radius]').forEach(b=>b.onclick=()=>{RADIUS=+b.dataset.radius;localStorage.setItem('riverflow-radius',RADIUS);draw()});$('#locate')?.addEventListener('click',requestLocation);if($('#favs'))$('#favs').onclick=()=>{FO=!FO;draw()};if($('#list'))$('#list').onclick=()=>{V='list';draw()};if($('#mapbtn'))$('#mapbtn').onclick=()=>{V='map';draw()};if($('#reload'))$('#reload').onclick=load;if($('#cuw'))$('#cuw').onclick=()=>open('https://data.cuwcd.gov/data/streamflows/index.htm','_blank');if($('#star'))$('#star').onclick=()=>toggle(S.id);if($('#back'))$('#back').onclick=()=>history.state?.riverflow?history.back():(S=null,draw());if($('#flyAdvisorFromRiver'))$('#flyAdvisorFromRiver').onclick=()=>{APP_TAB='bugs';localStorage.setItem('riverflow-main-tab','bugs');S=null;BUG_VIEW='advisor';draw();scrollTo(0,0)};if($('#bugFromRiver'))$('#bugFromRiver').onclick=()=>{APP_TAB='bugs';localStorage.setItem('riverflow-main-tab','bugs');S=null;BUG_VIEW='identify';draw();scrollTo(0,0)};document.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{D=+b.dataset.d;draw()})}
function openGauge(i){let g=G.find(x=>x.id===i);if(!g)return;localStorage.setItem('riverflow-last-gauge',i);Y=scrollY;S=g;history.pushState({riverflow:1},'',`#gauge-${i}`);draw();scrollTo(0,0)}
addEventListener('popstate',()=>{if(S){S=null;V='list';draw();requestAnimationFrame(()=>scrollTo(0,Y))}});

function markerHtml(g){let p=prof(g),both=p?.blue&&p?.trophyVerified,cls=both?'both':p?.trophyVerified?'trophyonly':p?.blue?'blueonly':'normal';return`<div class="rfpin ${cls}"><span>${p?.trophyVerified?'🏆':p?.blue?'◆':'•'}</span></div>`}
function mapCandidates(zoom){let a=LIST();if(MODE==='all'){a=a.filter(likelyFishing);if(zoom<=7)a=a.filter(g=>P[g.id]);else if(zoom<=9)a=a.filter(g=>P[g.id]||SCORE(g).n>=70)}else if(zoom<=6)a=a.filter(g=>P[g.id]);return a.slice(0,zoom>=9?350:120)}
function renderMapMarkers(layer){layer.clearLayers();let z=M.getZoom(),a=mapCandidates(z);a.forEach(g=>{if(!Number.isFinite(g.lat)||!Number.isFinite(g.lng))return;let p=prof(g),s=SCORE(g),d=distText(g),icon=L.divIcon({className:'rfIcon',html:markerHtml(g),iconSize:[30,30],iconAnchor:[15,15]});let m=L.marker([g.lat,g.lng],{icon}).addTo(layer).bindTooltip(`<b>${E(p?.title||g.name)}</b><br>${P[g.id]?`Score ${s.n} · `:''}${N(g.cfs)} cfs${g.tempF!=null?` · ${Math.round(g.tempF)}°F`:''}${d?` · ${d}`:''}`,{direction:'top',offset:[0,-10],permanent:!!P[g.id]&&((z>=7&&(p?.blue||p?.trophyVerified))||z>=9),className:'rfLabel'}).on('click',()=>openGauge(g.id));});if(LOC){let icon=L.divIcon({className:'rfIcon',html:'<div class="youPin"></div>',iconSize:[24,24],iconAnchor:[12,12]});L.marker([LOC.lat,LOC.lng],{icon,zIndexOffset:1000}).addTo(layer).bindTooltip('You',{permanent:false})}}
function map(){let e=$('#map');if(!e||!window.L)return;let center=LOC?[LOC.lat,LOC.lng]:[42.3,-113],zoom=LOC?7:5;M=L.map(e,{zoomControl:true}).setView(center,zoom);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap',maxZoom:18}).addTo(M);let layer=L.layerGroup().addTo(M);renderMapMarkers(layer);M.on('zoomend',()=>renderMapMarkers(layer));if(LOC)L.circle([LOC.lat,LOC.lng],{radius:Math.min(LOC.acc||500,2500),color:'#ffffff',weight:1,fillOpacity:.04,opacity:.3}).addTo(M)}

function chart(p){let e=$('#chart');if(!e)return;if(!p.length){e.innerHTML='<div class="empty">No recent history.</div>';return}let v=p.map(x=>x.value),mn=Math.min(...v),mx=Math.max(...v),s=mx-mn||1,d=p.map((x,i)=>`${i?'L':'M'} ${12+i/(p.length-1||1)*676} ${208-(x.value-mn)/s*190}`).join(' ');e.className='chart';e.innerHTML=`<svg viewBox="0 0 700 220"><line class="grid" x1="12" y1="208" x2="688" y2="208"/><path class="line" d="${d}"/></svg><div class="meta"><span>${Math.round(mn)}–${Math.round(mx)} cfs</span><span>${D}-day range</span></div>`}
async function historyLoad(){try{let r=await fetch(`https://riverflow-v2-history.vercel.app/api/history?site=${S.id}&days=${D}`),j=await r.json();chart(j.points||[])}catch{chart([])}}
function icon(s){s=(s||'').toLowerCase();return s.includes('thunder')?'⛈':s.includes('snow')?'❄':s.includes('rain')||s.includes('shower')?'🌧':s.includes('partly')?'🌤':s.includes('cloud')?'☁':'☀'}
function weatherHtml(j){let e=$('#weather'),a=j.days||[];if(!e)return;if(!a.length){e.innerHTML='<span class="pill">5-day forecast</span><h2>Weather unavailable</h2>';return}e.innerHTML=`<span class="pill">5-day forecast</span><h2>Weather at this gauge</h2><p class="muted big">Exact river-location forecast · wind included.</p><div class="weather">${a.map(d=>`<div class="day"><strong>${E(d.name)}</strong><div class="wxicon">${icon(d.forecast)}</div><div class="hi">${d.high??'—'}° <span class="muted">/ ${d.low??'—'}°</span></div><div class="desc">${E(d.forecast)}</div><div class="wrow"><span>Rain</span><b>${d.precip??0}%</b></div><div class="wrow"><span>Wind</span><b>${E(d.windDirection)} ${E(d.windSpeed)}</b></div></div>`).join('')}</div>`}
async function getWeather(g){if(WX[g.id])return WX[g.id];let r=await fetch(`https://riverflow-v2-weather.vercel.app/api/weather?lat=${g.lat}&lng=${g.lng}`),j=await r.json();if(!r.ok)throw 0;WX[g.id]=j;return j}
async function weather(){try{weatherHtml(await getWeather(S))}catch{weatherHtml({days:[]})}}
let prefetching=false;async function prefetch(){if(prefetching||!(PLAN==='now'||PLAN==='weekend'))return;let cand=G.filter(g=>P[g.id]).sort((a,b)=>SCORE(b).n-SCORE(a).n).slice(0,12),need=cand.filter(g=>!WX[g.id]);if(!need.length)return;prefetching=true;await Promise.allSettled(need.map(getWeather));prefetching=false;if(!S)draw()}
async function load(){if(!S)app.innerHTML='<div class="load">Loading live river intelligence…</div>';try{let r=await fetch('https://riverflow-v2-gauges.vercel.app/api/gauges?ts='+Date.now()),j=await r.json();if(!r.ok)throw Error(j.error||'River data error');G=(j.gauges||[]).filter(x=>Number.isFinite(x.cfs));STALE=false;CACHE_TIME=Date.now();localStorage.setItem('rf-gauges-cache',JSON.stringify({t:CACHE_TIME,g:G}));let q=new URLSearchParams(location.search).get('gauge');draw();if(q&&G.some(x=>x.id===q))openGauge(q)}catch(e){try{let c=JSON.parse(localStorage.getItem('rf-gauges-cache')||'null');if(c?.g?.length){G=c.g;STALE=true;CACHE_TIME=c.t||0;draw();return}}catch{}app.innerHTML=`<div class="err"><b>Couldn’t reach river data.</b><br>${E(e.message)}<br><small>Try refresh in a moment.</small></div>`}}
initFlyBoxes().finally(load);
