# RiverFlow River Intelligence v1.2

Built: 2026-08-13

## Scoring rules
RiverScore is a trip-planning score, not a promise of fishing success. Right Now / This Weekend combines live USGS flow freshness, water temperature where available, seasonal fit, NWS wind/precipitation, and the freshness/rating of a dated local fishing report. A Blue Ribbon designation receives only a modest boost. Verified trophy evidence receives only a small boost so a famous big-fish river cannot outrank safer/better current conditions by reputation alone.

Warm water receives a major penalty. Report influence decays automatically: <=7 days Fresh, <=14 Recent, <=30 Aging, >30 Stale/no score influence. Missing report data lowers the displayed Intel Confidence rather than being silently filled in.

## Trophy methodology
Three separate labels are used:
- Blue Ribbon: agency-reviewed/designated fishing quality; not synonymous with giant trout.
- Big-fish potential: legitimate reputation/management context but insufficient reach-specific size evidence for a verified badge.
- Verified Big Fish: agency survey, record or management evidence documents genuinely large fish in that system/reach.

A rare record fish does not mean record-size fish are common. The South Fork Snake profile explicitly notes that 30+ inch browns are verified but exceptionally rare.

## Primary agency evidence
Utah Division of Wildlife Resources
- Blue Ribbon Fisheries: https://wildlife.utah.gov/blueribbon

Wyoming Game & Fish Department
- Stream categorization / Blue Ribbon thresholds and map: https://wgfd.wyo.gov/aquatic-habitat/stream-categorization
- Fishing in the Heat (current status page): https://wgfd.wyo.gov/fishing-boating/fishing-heat
- July 29, 2026 Snake River warm-water notice: https://wgfd.wyo.gov/news-events/game-and-fish-announces-voluntary-catch-and-release-fishing-closures-snake-river-and
- July 23, 2026 New Fork warm-water notice: https://wgfd.wyo.gov/news-events/game-and-fish-asks-anglers-help-protect-fisheries-pinedale-during-summer-heat

Idaho Fish and Game
- South Fork Snake 2026 record + rarity context: https://idfg.idaho.gov/article/georgia-angler-reels-new-idaho-catch-and-release-record-brown-trout
- Idaho catch-and-release records: https://idfg.idaho.gov/fish/record/catch-and-release
- Henrys Fork St. Anthony survey (fish to 25 in): https://idfg.idaho.gov/blog/2021/03/trout-populations-are-strong-henrys-fork-near-st-anthony
- Henrys Fork Warm River–Ashton survey (brown to 27 in): https://idfg.idaho.gov/blog/2022/06/trout-density-henrys-fork-snake-river
- Henrys Fork Fishing Planner: https://idfg.idaho.gov/ifwis/fishingplanner/water/1119497437574
- South Fork Boise Fishing Planner: https://idfg.idaho.gov/ifwis/fishingplanner/water/1157355435501

## Local report layer
Local guide/fly-shop reports are dated and displayed with source + age. RiverFlow does not treat a stale report as current fishing truth. Current source set includes Trout Bum 2, Fly Fish Food, Teton Troutfitters, Two Rivers Fishing Co., Henry's Fork Anglers, Orvis/WorldCast Anglers and Silver Bow Fly Shop where river-specific reports were available.

## Location and map
Nearby uses Android device location only after the angler requests it. The app displays straight-line mileage to the gauge, supports 25/50/100/200-mile filters, and links to Google Maps for actual routing. Exact coordinates are not persisted by RiverFlow.

The fishing map suppresses canals, drains, sewage/flood infrastructure and most ordinary gauges at regional zoom. Blue Ribbon and Verified Big Fish markers are visually distinct; their labels appear earlier as the user zooms in.

## Important
Designations, access, regulations, closures and advisories can change. RiverFlow links to the relevant official source when possible and tells the angler to verify current status before fishing.
