# RiverFlow River Intelligence v1.1

Built: 2026-08-13

## Method
RiverScore is a planning score, not a guarantee of fishing success. For Right Now / This Weekend it combines:
- live USGS flow availability/freshness
- live water temperature where a gauge reports it
- river-specific seasonal peak windows
- NWS wind/precipitation when the app has loaded the gauge forecast
- curated Blue Ribbon priority
- separate trophy-potential profile

For Spring / Summer / Fall / Winter planning, live August/real-time conditions are intentionally not used to rank another season.

Warm-water trout conditions receive a large negative score. Trophy Potential is separate from RiverScore because trophy-size fish and high catch rates are not the same thing.

## Primary agency evidence used for first curated profiles

Utah Division of Wildlife Resources
- Blue Ribbon Fisheries: https://wildlife.utah.gov/blueribbon
- 2026 fishing recommendations (Middle Provo seasonal context): https://wildlife.utah.gov/news/2026/05/20/great-places-to-go-fishing-on-memorial-day-weekend-and-free-fishing-day
- Utah record fish (upper Provo brown trout context): https://wildlife.utah.gov/fishing/records

Wyoming Game & Fish Department
- Stream categorization: https://wgfd.wyo.gov/aquatic-habitat/stream-categorization
- Blue Ribbon stream list: https://wgfd.wyo.gov/Ask-Game-and-Fish/Mark%2C-what-is-a-blue-ribbon-stream%2C-and-where-are
- 2026 warm-water trout advisory: https://wgfd.wyo.gov/news-events/game-and-fish-asks-anglers-protect-trout-upper-north-platte-and-encampment-rivers

Idaho Fish and Game
- South Fork Boise trophy trout surveys: https://idfg.idaho.gov/blog/2021/06/wild-trout-and-wildfire-monitoring-trout-populations-south-fork-boise-river-after
- South Fork Boise Fishing Planner: https://idfg.idaho.gov/ifwis/fishingplanner/water/1157355435501
- Henrys Fork St. Anthony survey: https://idfg.idaho.gov/blog/2021/03/trout-populations-are-strong-henrys-fork-near-st-anthony
- Henrys Fork size structure: https://idfg.idaho.gov/blog/2022/06/trout-density-henrys-fork-snake-river
- Henrys Fork Fishing Planner: https://idfg.idaho.gov/ifwis/fishingplanner/water/1119497437574
- Silver Creek Fishing Planner: https://idfg.idaho.gov/ifwis/fishingplanner/water/1140111432006

## Important
Blue Ribbon status can be reach-specific. The app only gives the prominent Blue Ribbon badge to curated gauges/reaches in this first version. More exact geospatial reach mapping should be added over time.

Trophy ratings with High confidence are backed by agency fish survey/management information. Moderate confidence profiles use a mix of agency designation, special regulations, fishery characteristics, and documented fishery reputation and should be refined as newer survey data becomes available.
