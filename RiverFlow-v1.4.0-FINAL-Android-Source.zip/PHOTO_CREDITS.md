# RiverFlow Bug Reference Photo Credits

RiverFlow v1.3.8 uses real-world reference photographs loaded from Wikimedia Commons when an internet connection is available. A reduced copy is cached locally in the app when browser/WebView storage and CORS allow it. Bundled local macro-style images are used as offline fallbacks.

- Blue-Winged Olive (Baetis): `Baetis P1650539a.jpg` — Robert Webster / xpda.com — CC BY-SA 4.0.
- Pale Morning Dun group: `Mayfly at Seedskadee National Wildlife Refuge (50038493066).jpg` — Tom Koerner / USFWS Mountain-Prairie — Wikimedia Commons.
- Green Drake: `Western Green Drake (Drunella grandis) larva.jpg` — Wikimedia Commons.
- Callibaetis: `Callibaetis P1370243a.jpg` — Robert Webster / xpda.com — CC BY-SA 4.0.
- Trico: `Little stout crawler mayfly, genus Tricorythodes (9465265969).jpg` — Bob Henricks — CC BY-SA 2.0.
- Mahogany / Paraleptophlebia: `Pronggilled mayfly, genus Paraleptophlebia (8271390300).jpg` — Bob Henricks — CC BY-SA 2.0.
- Grannom / Brachycentrus: `Caddis Fly. Brachycentrus subnubilus^ Brachycentridae - Flickr - gailhampshire (1).jpg` — gailhampshire — Wikimedia Commons.
- Spotted Sedge / Hydropsyche: `Caddisfly Hydropsyche species.( possibly H. siltalai) (48958513252).jpg` — gailhampshire — CC BY 2.0.
- October Caddis / Dicosmoecus: `Dicosmoecus gilvipes 164831753.jpg` — Gabrielle Casciato — Wikimedia Commons.
- Little Black Caddis: `Genus Chimarra Little Black Caddisfly iNaturalist122139766.jpg` — Jimmy Whatmore — CC0.
- Green/net-spinning caddis larva: `Common netspinner caddis, Hydropsyche betteni (8094735425).jpg` — Bob Henricks — Wikimedia Commons.
- Caddis pupa: `Caddis pupae.JPG` — Waldemar Paetz — CC BY-SA 4.0.
- Bloodworm / red chironomid larva: `Single Bloodworm.jpg` — Bill Kasman — CC0.
- Dark chironomid larva: `Chironomidae larva-pjt.jpg` — Wikimedia Commons.
- Chironomid pupa: `Non-biting midge pupae (1d84e3a6-155d-451f-674c-68f193589875).jpg` — U.S. National Park Service — Wikimedia Commons.
- Emerging midge: `Emergent midge. Rhopalomyia solidaginis.jpg` — Beatriz Moisset — Wikimedia Commons.
- Adult midge: `Chironomidae Non-biting Midge.jpg` — Jean and Fred — CC BY 2.0.
- Midge swarm: `Midge swarm at Arapaho National Wildlife Refuge (48259559166).jpg` — Tom Koerner / USFWS — Public Domain Mark.

Each photo's source page is linked from its RiverFlow detail card.


## v1.3.8 lifecycle / alternate reference additions
- Mayfly emerger: `Mayfly ecdysis.jpg` — Stemonitis — CC BY-SA 2.5.
- BWO dun/subimago: `Baetis tricaudatus male subimago crop.jpg` — JerryFriedman — CC BY-SA 3.0.
- BWO mature adult: `Baetis tricaudatus male imago.jpg` — JerryFriedman — CC BY-SA 3.0.
- PMD nymph: `Spiny crawler mayfly, Ephemerella dorothea (8561750415).jpg` — Bob Henricks — CC BY-SA.
- Caddis larva: `Caddisfly Larva.jpg` — MyForest — Wikimedia Commons.
- Adult stonefly: `Plecoptera - stonefly (7737944938).jpg` — Guido Bohne — CC BY-SA 2.0.
- Alternate scud: `Gammarus pulex 14875938.jpg` / `Gammarus pulex 14875940.jpg` — Wikimedia Commons.
- Alternate sowbug: `Asellus aquaticus 04.2025 (1).jpg` / `(2).jpg` — DidierFy — CC BY-SA 4.0.

Representative lifecycle images are explicitly labeled in the app when they are not the exact selected species.
