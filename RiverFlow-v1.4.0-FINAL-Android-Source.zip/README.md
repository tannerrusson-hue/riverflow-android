# RiverFlow Android v1.4.0

Final navigation + field-viewer release.

## New in v1.4.0
- Fixed, thumb-friendly bottom navigation: **Home, Advisor, Bug Guide, Fly Boxes**.
- Removed duplicate top-level tab bars to reduce mobile clutter.
- Home remains the river-intelligence hub with list/map, nearby water, Blue Ribbon and verified big-fish filters.
- Rebuilt the full-screen insect viewer around Pointer Events for more reliable two-finger pinch zoom and drag/pan in Android WebView.
- Added visible **+ / − / Reset** zoom controls as a field-safe fallback.
- Multiple photo references and full life-cycle filtering remain on each bug detail page.
- Portrait-only Android behavior and local multi-fly-box storage remain enabled.
- Automatic paid-AI bug recognition remains intentionally disabled.

# RiverFlow Android v1.3.8

Field-guide and UI refinement release.

## New in v1.3.8
- Multiple reference photos on every Bug Reference detail page, with exact/close-match photos clearly distinguished from representative life-stage examples.
- Full life-cycle browsing: mayfly nymph → emerger → dun → spinner; caddis larva → pupa → adult; midge larva → pupa → adult; stonefly nymph → adult.
- Tap any reference image for a full-screen viewer with pinch-to-zoom, drag/pan, and double-tap zoom.
- Life-stage selection changes the recommended fly patterns and presentation on the same page.
- Added additional real-world reference views for BWO, PMD, Trico, Callibaetis, Mahogany, Stonefly, Scud and Sowbug.
- Home screen redesigned into a tighter field dashboard with a direct Fly Advisor shortcut, favorite-water shortcut, cleaner gauge stats, and less visual clutter.
- Portrait-only Android behavior remains enabled.
- Automatic AI Bug ID remains disabled; the field guide and recommendation engine work without paid AI.

# RiverFlow v1.3.0 — Bug ID + FlyBox Match

New in v1.3:
- New top-level **Bug ID + FlyBox** tab.
- Rear-camera bug photo capture inside RiverFlow.
- Guided field identification for mayflies, caddis, stoneflies, midges, and terrestrials.
- Life-stage, size, and color-aware fly-pattern recommendations.
- River-context rig/presentation advice using the last selected RiverFlow gauge.
- Bug Library with fast visual field cues.
- **My Fly Box**: photograph an open fly box once, tag the exact locations of flies, and save the map locally.
- **FlyBox Match**: RiverFlow ranks the flies you actually carry and highlights their exact positions in the saved box photo.
- **Live Fly Finder (beta)**: point the camera at the box and align it to the saved box image to see highlighted mapped fly positions.
- Android camera runtime permission + WebView camera permission handling.
- Android file/photo chooser fallback.

Important: automatic computer-vision insect recognition is not falsely simulated in this build. The camera, guided ID, recommendation engine, fly-box mapping, and live overlay are functional; the server-side vision model is the remaining connection required for fully automatic photo identification.

# RiverFlow Android v1.2

Mobile fly-fishing river intelligence for Utah, Wyoming and Idaho.

v1.2 tightens the decision layer: live gauge freshness, water temperature, weather/wind, dated local reports, verified agency Blue Ribbon evidence, conservative trophy evidence, current-location distance, fishing-only nearby results, and a decluttered fishing map. Blue Ribbon quality, big-fish potential, and verified big-fish evidence are intentionally separate signals.

The Android app contains the RiverFlow UI inside the APK and reads RiverFlow backend services for gauges, history and NWS weather. Nearby location is requested only when the angler taps Nearby; exact coordinates are kept in app memory for that session and are not saved by RiverFlow.

Build with `gradle :app:assembleDebug` using Android SDK 35 / Java 17+ / Gradle 8.9.


## v1.3.2 Fly Advisor
- Adds no-photo seasonal Fly Advisor.
- Uses selected river, current month/season, time of day, water temperature, report freshness, and river-specific hatch profiles.
- Matches seasonal recommendations against the user's saved My Fly Box inventory and can highlight exact mapped fly locations.
- Bug photo identification remains the higher-confidence on-water observation path when the vision backend is available.

## v1.3.4 multi-box Fly Advisor
RiverFlow can now keep multiple named fly boxes on-device. Box photos use IndexedDB, while lightweight box metadata/inventory stays local. Fly Advisor and Bug ID rank all mapped flies across all boxes and automatically select the #1 fly, with the source box and saved position shown.


## v1.3.7 guide flow
- Bug Reference cards now drill into one self-contained detail screen.
- Each detail screen includes reference photo, identification cues, life stage, integrated size guidance, recommended flies, rig advice, and saved fly-box matching.
- Added real-photo references for Stonefly, Scud, and Sowbug.
- Removed the separate Size Guide tab and Android camera permission.
