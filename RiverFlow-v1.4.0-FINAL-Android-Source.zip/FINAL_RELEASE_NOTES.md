# RiverFlow v1.4.0 — Final Release Notes

This release consolidates the mobile UI and closes the two most recent field-guide issues.

## Finalized
- Four-tab fixed bottom navigation: Home / Advisor / Bug Guide / Fly Boxes.
- Removed duplicate top navigation from the main app views.
- Portrait-only Android behavior retained.
- Multiple real-world reference views on bug details.
- Full life-cycle stage selection with recommendations updated on the same page.
- Hardened full-screen image viewer using Pointer Events for Android multi-touch.
- Added + / − / Reset zoom buttons as a reliable fallback.
- Multi-box local storage and automatic fly ranking preserved.

## Verification performed
- JavaScript syntax validation passed.
- Mobile render test at 390 × 844 passed with no page errors.
- Bottom navigation count: 4.
- PMD reference gallery: 6 views.
- PMD life-cycle tabs: Overview, Nymph, Emerger, Dun / adult, Spinner.
- Zoom control test: 1.0× → 1.5×.
- Simulated two-finger pinch test: 1.0× → 1.6×.

## Scope
Automatic paid-AI insect recognition remains disabled intentionally. The Bug Guide is a manual visual reference and the Fly Advisor uses seasonal/river context plus the user's locally mapped fly boxes.
