# RiverFlow Android v1.4.0 phone build

- Portrait-only Android app.
- Fixed bottom navigation: Home, Advisor, Bug Guide, Fly Boxes.
- River intelligence, list/map, nearby-water distance, Blue Ribbon and verified big-fish filters remain on Home.
- Multiple bug-reference photos per entry with full life-cycle browsing.
- Stage-specific fly recommendations on the same bug detail screen.
- Full-screen photo viewer with two-finger pinch zoom, drag/pan, double-tap behavior, and + / − / Reset controls.
- Multiple named fly boxes saved locally on the phone and searched automatically by Fly Advisor.
- No paid AI Bug ID required.
- Fly-box photos/inventory stay on-device.

Build requirements: Java 17+, Android SDK 35, Gradle 8.9.
Build command: `gradle :app:assembleDebug`
